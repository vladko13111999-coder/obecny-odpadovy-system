# 🚀 Deployment Guide - Obecný Odpadový Systém

Tento návod vás prevedie kompletným procesom nasadenia aplikácie do produkcie.

## 📋 Predpoklady

Pred začatím sa uistite, že máte:
- ✅ Účet na [Supabase](https://supabase.com)
- ✅ Účet na [Stripe](https://stripe.com)
- ✅ Účet na [Vercel](https://vercel.com) (alebo inú hosting platformu)
- ✅ Git nainštalovaný lokálne

## 1️⃣ Supabase Setup

### 1.1 Vytvorenie projektu

1. Prihláste sa na [supabase.com](https://supabase.com)
2. Kliknite na "New Project"
3. Vyplňte:
   - **Name:** odpadovy-system
   - **Database Password:** (uložte si ho bezpečne)
   - **Region:** Europe (Frankfurt) - najbližšia k Slovensku
4. Kliknite "Create new project"

### 1.2 Spustenie databázovej schémy

1. V Supabase dashboarde prejdite na **SQL Editor**
2. Kliknite "New Query"
3. Skopírujte celý obsah súboru `database_schema.sql`
4. Vložte do editora a kliknite "Run"
5. Overte, že všetky tabuľky boli vytvorené v sekcii **Table Editor**

### 1.3 Povolenie Email Authentication

1. Prejdite na **Authentication** → **Providers**
2. Nájdite **Email** provider
3. Zapnite ho (toggle switch)
4. Nastavte:
   - **Enable Email Confirmations:** OFF (pre jednoduchosť, v produkcii zapnite)
   - **Secure Email Change:** ON
5. Uložte zmeny

### 1.4 Získanie API kľúčov

1. Prejdite na **Settings** → **API**
2. Skopírujte:
   - **Project URL** (napr. `https://xxxxx.supabase.co`)
   - **anon public** key
   - **service_role** key (POZOR: tento kľúč nikdy nezverejňujte!)

## 2️⃣ Stripe Setup

### 2.1 Vytvorenie účtu

1. Prihláste sa na [stripe.com](https://stripe.com)
2. Prejdite do **Test Mode** (prepínač vpravo hore)

### 2.2 Vytvorenie produktov

1. Prejdite na **Products** → **Add Product**
2. Vytvorte 3 produkty:

**Produkt 1: Malá obec**
- Name: Obecný odpadový systém - Malá obec
- Description: Mesačné predplatné pre malé obce (do 1000 obyvateľov)
- Pricing: 49 EUR / month (recurring)

**Produkt 2: Stredná obec**
- Name: Obecný odpadový systém - Stredná obec
- Description: Mesačné predplatné pre stredné obce (1000-5000 obyvateľov)
- Pricing: 99 EUR / month (recurring)

**Produkt 3: Veľká obec**
- Name: Obecný odpadový systém - Veľká obec
- Description: Mesačné predplatné pre veľké obce (nad 5000 obyvateľov)
- Pricing: 149 EUR / month (recurring)

### 2.3 Získanie API kľúčov

1. Prejdite na **Developers** → **API keys**
2. Skopírujte:
   - **Publishable key** (začína `pk_test_`)
   - **Secret key** (začína `sk_test_`)

### 2.4 Nastavenie Webhooku

**POZOR:** Webhook nastavíte až po nasadení aplikácie na Vercel (krok 4)

## 3️⃣ Lokálne testovanie

### 3.1 Inštalácia závislostí

```bash
cd odpadovy-system
pnpm install
```

### 3.2 Nastavenie environment premenných

Vytvorte súbor `.env.local`:

```bash
cp .env.example .env.local
```

Vyplňte všetky premenné:

```env
# Supabase
NEXT_PUBLIC_SUPABASE_URL=https://xxxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGc...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGc...

# Stripe
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_... # Zatiaľ nechajte prázdne

# App
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

### 3.3 Spustenie vývojového servera

```bash
pnpm dev
```

Aplikácia bude dostupná na [http://localhost:3000](http://localhost:3000)

### 3.4 Testovanie

1. Otvorte [http://localhost:3000](http://localhost:3000)
2. Kliknite "Registrovať obec"
3. Vyplňte formulár a zaregistrujte sa
4. Prihláste sa a otestujte:
   - Pridanie obyvateľov
   - Pridanie vývozov
   - Generovanie reportov
   - Správu odmien
   - Kalendár

## 4️⃣ Nasadenie na Vercel

### 4.1 Push do Git repozitára

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/your-username/odpadovy-system.git
git push -u origin main
```

### 4.2 Nasadenie na Vercel

1. Prihláste sa na [vercel.com](https://vercel.com)
2. Kliknite "Add New" → "Project"
3. Importujte váš Git repozitár
4. Nastavte:
   - **Framework Preset:** Next.js
   - **Root Directory:** ./
   - **Build Command:** `pnpm build`
   - **Output Directory:** .next

### 4.3 Nastavenie Environment Variables

V Vercel dashboarde:

1. Prejdite na **Settings** → **Environment Variables**
2. Pridajte všetky premenné z `.env.local`:

```
NEXT_PUBLIC_SUPABASE_URL
NEXT_PUBLIC_SUPABASE_ANON_KEY
SUPABASE_SERVICE_ROLE_KEY
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY
STRIPE_SECRET_KEY
STRIPE_WEBHOOK_SECRET (zatiaľ prázdne)
NEXT_PUBLIC_APP_URL (napr. https://odpadovy-system.vercel.app)
```

3. Kliknite "Save"
4. Kliknite "Redeploy" pre opätovné nasadenie s novými premennými

### 4.4 Nastavenie Stripe Webhooku

1. Skopírujte vašu Vercel URL (napr. `https://odpadovy-system.vercel.app`)
2. V Stripe dashboarde prejdite na **Developers** → **Webhooks**
3. Kliknite "Add endpoint"
4. Vyplňte:
   - **Endpoint URL:** `https://odpadovy-system.vercel.app/api/stripe/webhook`
   - **Events to send:** Vyberte:
     - `checkout.session.completed`
     - `customer.subscription.deleted`
     - `customer.subscription.updated`
5. Kliknite "Add endpoint"
6. Skopírujte **Signing secret** (začína `whsec_`)
7. V Vercel dashboarde pridajte premennú:
   - **Name:** `STRIPE_WEBHOOK_SECRET`
   - **Value:** `whsec_...`
8. Kliknite "Redeploy"

## 5️⃣ Finálne testovanie

### 5.1 Testovanie registrácie

1. Otvorte vašu produkčnú URL
2. Zaregistrujte novú obec
3. Overte, že trial obdobie funguje (30 dní)

### 5.2 Testovanie platieb

1. Prihláste sa ako starosta
2. Prejdite na **Nastavenia**
3. Kliknite "Aktivovať predplatné"
4. Použite testovaciu kartu Stripe:
   - **Číslo:** 4242 4242 4242 4242
   - **Dátum:** Akýkoľvek budúci dátum
   - **CVC:** Akékoľvek 3 číslice
5. Overte, že po platbe sa stav zmení na "Aktívne"

### 5.3 Testovanie občanov

1. Ako starosta pridajte obyvateľa
2. Poznačte si jeho ID
3. Odhláste sa
4. Kliknite "Registrácia občana"
5. Použite ID ako overovací kód
6. Dokončite registráciu
7. Prihláste sa ako občan a otestujte portál

## 6️⃣ Prechod do produkcie

### 6.1 Stripe Production Mode

1. V Stripe dashboarde prepnite z **Test Mode** na **Live Mode**
2. Vytvorte rovnaké produkty ako v test mode
3. Získajte production API keys
4. Vytvorte production webhook
5. Aktualizujte environment variables vo Vercel

### 6.2 Supabase Production

1. Overte RLS politiky
2. Zapnite Email Confirmations
3. Nastavte SMTP pre email notifikácie
4. Zapnite Database Backups

### 6.3 Monitoring

1. V Vercel zapnite **Analytics**
2. V Supabase sledujte **Database Health**
3. V Stripe sledujte **Payments** a **Subscriptions**

## 🔒 Bezpečnosť

### Dôležité upozornenia:

- ❌ **NIKDY** nezverejňujte `SUPABASE_SERVICE_ROLE_KEY`
- ❌ **NIKDY** nezverejňujte `STRIPE_SECRET_KEY`
- ❌ **NIKDY** nezverejňujte `STRIPE_WEBHOOK_SECRET`
- ✅ Používajte `.env.local` pre lokálny vývoj
- ✅ Používajte Environment Variables vo Vercel
- ✅ Pridajte `.env.local` do `.gitignore`

## 📞 Podpora

Pre otázky a problémy:
- 📧 Email: support@odpadovy-system.sk
- 📚 Dokumentácia: README.md
- 🐛 Issues: GitHub Issues

---

**Gratulujeme! Vaša aplikácia je teraz nasadená a pripravená na používanie! 🎉**
