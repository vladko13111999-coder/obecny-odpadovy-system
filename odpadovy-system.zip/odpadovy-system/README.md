# 🗑️ Obecný Odpadový Systém

Komplexná SaaS aplikácia pre slovenské obce na evidenciu odpadu, gamifikáciu triedenia a generovanie kvartálnych reportov pre ISOH.

## 📋 Funkcie

- ✅ **Správa obyvateľov** - CRUD operácie s obyvateľmi obce
- ✅ **Evidencia vývozov** - Zaznamenávanie vývozu odpadu s automatickým bodovaním
- ✅ **Bodovací systém** - 2 body za každý kg triedeného odpadu (plast, papier, sklo)
- ✅ **Kvartálne reporty** - Generovanie XML/CSV/XLSX reportov pre ISOH podľa vyhlášky č. 366/2015 Z.z.
- ✅ **Gamifikácia** - Rebríček obyvateľov, odmeny, obchodík
- ✅ **Kalendár vývozov** - Harmonogram zvozu odpadu
- ✅ **Predplatné** - Integrácia so Stripe, 30-dňový trial
- ✅ **Oddelenie rolí** - Starosta vs. Občan

## 🛠️ Technológie

- **Frontend:** Next.js 16 (Pages Router) + TypeScript + Tailwind CSS
- **Backend:** Supabase (PostgreSQL + Auth + Storage)
- **Platby:** Stripe
- **Knižnice:** recharts, exceljs, xml2js, react-calendar

## 🚀 Inštalácia

### 1. Klonujte repozitár

```bash
git clone <repository-url>
cd odpadovy-system
```

### 2. Nainštalujte závislosti

```bash
pnpm install
```

### 3. Nastavte Supabase

1. Vytvorte nový projekt na [supabase.com](https://supabase.com)
2. V Supabase SQL Editor spustite skript `database_schema.sql`
3. Povoľte Email Authentication v Dashboard → Authentication → Providers

### 4. Nastavte Stripe

1. Vytvorte účet na [stripe.com](https://stripe.com)
2. Prejdite do testovacieho režimu
3. Vytvorte tri produkty s cenami:
   - Malá obec: 49 €/mesiac
   - Stredná obec: 99 €/mesiac
   - Veľká obec: 149 €/mesiac
4. Nastavte webhook endpoint: `https://your-domain.com/api/stripe/webhook`
5. Vyberte udalosť: `checkout.session.completed`

### 5. Nastavte environment premenné

Vytvorte súbor `.env.local` na základe `.env.example`:

```bash
cp .env.example .env.local
```

Vyplňte všetky potrebné premenné:

```env
# Supabase
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key

# Stripe
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...

# App
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

### 6. Spustite vývojový server

```bash
pnpm dev
```

Aplikácia bude dostupná na [http://localhost:3000](http://localhost:3000)

## 📁 Štruktúra projektu

```
odpadovy-system/
├── src/
│   ├── pages/
│   │   ├── api/              # API routes
│   │   ├── auth/             # Autentifikácia
│   │   ├── dashboard/        # Dashboard starostu
│   │   ├── citizen/          # Portál občana
│   │   └── index.tsx         # Landing page
│   ├── components/           # React komponenty
│   ├── lib/                  # Utility funkcie
│   │   ├── supabase.ts       # Supabase client
│   │   └── stripe.ts         # Stripe client
│   ├── types/                # TypeScript typy
│   └── styles/               # CSS štýly
├── database_schema.sql       # SQL schéma databázy
├── .env.example              # Príklad environment premenných
└── README.md                 # Tento súbor
```

## 🗄️ Databázová schéma

### Tabuľky

1. **obce** - Údaje o obciach (starosta)
2. **obyvatelia** - Zoznam obyvateľov
3. **vyvozy** - Evidencia vývozov odpadu
4. **odmeny** - Katalóg odmien
5. **harmonogram** - Kalendár vývozov
6. **reporty** - Archív vygenerovaných reportov

### Automatizácia

- **Triggery** na automatické pripočítavanie bodov pri vývozoch
- **RLS politiky** na zabezpečenie dát podľa obce
- **Indexy** pre optimalizáciu výkonu

## 📊 Katalógové čísla odpadu (ISOH)

Podľa prílohy č. 2 vyhlášky č. 366/2015 Z.z.:

| Typ odpadu | Kód odpadu |
|------------|------------|
| Plast      | 20 01 39   |
| Papier     | 20 01 01   |
| Sklo       | 20 01 02   |
| Zmesový    | 20 03 01   |

**Kód nakladania:** `OO` (odovzdanie obchodníkovi)

## 🎯 Cenové plány

| Plán | Cena | Vhodné pre |
|------|------|------------|
| Malá obec | 49 €/mesiac | Do 1000 obyvateľov |
| Stredná obec | 99 €/mesiac | 1000-5000 obyvateľov |
| Veľká obec | 149 €/mesiac | Nad 5000 obyvateľov |

**Trial:** 30 dní zadarmo pre všetky plány

## 🚢 Nasadenie

### Vercel (odporúčané)

```bash
# Nainštalujte Vercel CLI
pnpm add -g vercel

# Nasaďte
vercel
```

Nezabudnite nastaviť environment premenné v Vercel Dashboard.

### Iné platformy

Aplikácia je kompatibilná s akoukoľvek platformou podporujúcou Next.js:
- Netlify
- AWS Amplify
- Railway
- Render

## 📝 Licencia

Proprietárne - Všetky práva vyhradené

## 🤝 Podpora

Pre otázky a podporu kontaktujte: [váš email]

---

Vytvorené pre slovenské obce 🇸🇰
