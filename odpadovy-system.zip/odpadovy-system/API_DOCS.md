# 📡 API Documentation

Dokumentácia všetkých API endpointov v aplikácii Obecný Odpadový Systém.

---

## 🔐 Autentifikácia

Všetky API endpointy vyžadujú autentifikáciu cez Supabase. Token sa automaticky posiela v HTTP hlavičke.

---

## 📊 Reports API

### `POST /api/reports/generate`

Generuje nový kvartálny report pre ISOH.

**Request Body:**
```json
{
  "kvartal": 1,
  "rok": 2024
}
```

**Response:**
```json
{
  "message": "Report úspešne vygenerovaný",
  "kvartal": 1,
  "rok": 2024
}
```

**Errors:**
- `400` - Chýbajúce parametre alebo žiadne vývozy za kvartál
- `401` - Neautorizovaný prístup
- `500` - Chyba servera

---

### `GET /api/reports/download?id={reportId}&format={format}`

Stiahne vygenerovaný report v požadovanom formáte.

**Query Parameters:**
- `id` (required) - ID reportu
- `format` (required) - Formát súboru: `xml`, `csv`, alebo `xlsx`

**Response:**
- Súbor na stiahnutie s príslušným Content-Type

**Errors:**
- `400` - Neplatný formát
- `401` - Neautorizovaný prístup
- `404` - Report nenájdený
- `500` - Chyba servera

---

## 💳 Stripe API

### `POST /api/stripe/create-checkout-session`

Vytvorí Stripe checkout session pre aktiváciu predplatného.

**Request Body:**
```json
{
  "velkost_obce": "mala"
}
```

**Response:**
```json
{
  "url": "https://checkout.stripe.com/..."
}
```

**Errors:**
- `400` - Chýbajúca veľkosť obce
- `401` - Neautorizovaný prístup
- `404` - Obec nenájdená
- `500` - Chyba servera

---

### `POST /api/stripe/webhook`

Webhook endpoint pre Stripe udalosti.

**Headers:**
- `stripe-signature` (required) - Stripe signature pre verifikáciu

**Supported Events:**
- `checkout.session.completed` - Aktivácia predplatného
- `customer.subscription.deleted` - Zrušenie predplatného
- `customer.subscription.updated` - Aktualizácia predplatného

**Response:**
```json
{
  "received": true
}
```

**Errors:**
- `400` - Neplatný webhook alebo chýbajúca signature
- `404` - Obec nenájdená
- `500` - Chyba servera

---

## 📝 Formáty reportov

### XML (ISOH)

XML report je štruktúrovaný podľa vyhlášky č. 366/2015 Z.z.

**Štruktúra:**
```xml
<?xml version="1.0" encoding="UTF-8"?>
<Report>
  <Obec>
    <Nazov>Obec XY</Nazov>
    <ICO>12345678</ICO>
  </Obec>
  <Obdobie>
    <Kvartal>1</Kvartal>
    <Rok>2024</Rok>
  </Obdobie>
  <Vyvozy>
    <Vyvoz>
      <Datum>2024-01-15</Datum>
      <TypOdpadu>plast</TypOdpadu>
      <KodOdpadu>20 01 39</KodOdpadu>
      <Mnozstvo>15.5</Mnozstvo>
      <KodNakladania>OO</KodNakladania>
    </Vyvoz>
    <!-- ... -->
  </Vyvozy>
</Report>
```

### CSV

CSV report obsahuje všetky vývozy v tabuľkovom formáte.

**Stĺpce:**
- Dátum
- Typ odpadu
- Kód odpadu
- Množstvo (kg)
- Kód nakladania

**Príklad:**
```csv
Dátum,Typ odpadu,Kód odpadu,Množstvo (kg),Kód nakladania
2024-01-15,plast,20 01 39,15.5,OO
2024-01-20,papier,20 01 01,8.2,OO
```

### XLSX

Excel report obsahuje rovnaké údaje ako CSV, ale vo formáte Excel s formátovaním.

**Features:**
- Hlavička s názvom obce a obdobím
- Formátované stĺpce
- Súčty na konci

---

## 🔒 Bezpečnosť

### Row Level Security (RLS)

Všetky tabuľky majú RLS politiky, ktoré zabezpečujú:
- Obce vidia len svoje dáta
- Obyvatelia vidia len svoje dáta
- Starostovia majú plný prístup k dátam svojej obce

### API Keys

- `SUPABASE_ANON_KEY` - Verejný kľúč pre frontend
- `SUPABASE_SERVICE_ROLE_KEY` - Súkromný kľúč pre backend (NIKDY nezverejňovať!)
- `STRIPE_SECRET_KEY` - Súkromný kľúč pre Stripe (NIKDY nezverejňovať!)

---

## 📞 Rate Limiting

Momentálne nie sú implementované rate limity. V produkcii odporúčame:
- Max 100 requestov/minútu na používateľa
- Max 10 generovaní reportov/hodinu na obec

---

## 🐛 Error Handling

Všetky API endpointy vracajú štandardizované error response:

```json
{
  "message": "Popis chyby"
}
```

**HTTP Status Codes:**
- `200` - OK
- `400` - Bad Request (neplatné parametre)
- `401` - Unauthorized (chýbajúca autentifikácia)
- `404` - Not Found (zdroj nenájdený)
- `405` - Method Not Allowed (neplatná HTTP metóda)
- `500` - Internal Server Error (chyba servera)

---

## 📚 Ďalšie zdroje

- [Supabase Docs](https://supabase.com/docs)
- [Stripe API Docs](https://stripe.com/docs/api)
- [Next.js API Routes](https://nextjs.org/docs/api-routes/introduction)
