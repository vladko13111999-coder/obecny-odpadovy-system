import { generateXMLReport, generateCSVReport, filterCollectionsByQuarter } from './src/lib/reports';
import { Obec, Vyvoz, Obyvatel } from './src/types/database';

// Mock data for testing
const mockObec: Obec = {
  id: 1,
  auth_user_id: 'user-123',
  nazov: 'Testovacia Obec',
  email: 'obec@test.sk',
  ico: '12345678',
  ulica: 'Hlavná 1',
  mesto: 'Bratislava',
  psc: '81101',
  velkost_obce: 'stredna',
  subscription_status: 'active',
  trial_start: new Date().toISOString(),
  trial_end: new Date().toISOString(),
  created_at: new Date().toISOString(),
};

const mockObyvatelia: Obyvatel[] = [
  {
    id: 1,
    obec_id: 1,
    meno: 'Ján',
    priezvisko: 'Novák',
    ulica: 'Mierová',
    cislo_popisne: '10',
    celkove_body: 0,
    created_at: new Date().toISOString(),
  },
  {
    id: 2,
    obec_id: 1,
    meno: 'Mária',
    priezvisko: 'Veselá',
    ulica: 'Záhradná',
    cislo_popisne: '5',
    celkove_body: 0,
    created_at: new Date().toISOString(),
  }
];

const mockVyvozy: Vyvoz[] = [
  {
    id: 1,
    obec_id: 1,
    obyvatel_id: 1,
    datum: '2024-01-15',
    typ_odpadu: 'plast',
    mnozstvo_kg: 10.5,
    kod_odpadu: '20 01 39',
    kod_nakladania: 'OO',
    created_at: new Date().toISOString(),
  },
  {
    id: 2,
    obec_id: 1,
    obyvatel_id: 1,
    datum: '2024-02-20',
    typ_odpadu: 'papier',
    mnozstvo_kg: 5.0,
    kod_odpadu: '20 01 01',
    kod_nakladania: 'OO',
    created_at: new Date().toISOString(),
  },
  {
    id: 3,
    obec_id: 1,
    obyvatel_id: 2,
    datum: '2024-03-10',
    typ_odpadu: 'sklo',
    mnozstvo_kg: 8.2,
    kod_odpadu: '20 01 02',
    kod_nakladania: 'OO',
    created_at: new Date().toISOString(),
  },
  {
    id: 4,
    obec_id: 1,
    obyvatel_id: 2,
    datum: '2024-03-25',
    typ_odpadu: 'zmesovy',
    mnozstvo_kg: 20.0,
    kod_odpadu: '20 03 01',
    kod_nakladania: 'OO',
    created_at: new Date().toISOString(),
  }
];

async function runTests() {
  console.log('--- 🧪 ZAČIATOK TESTOVANIA SYSTÉMU ---');

  // 1. Test filtrovania podľa kvartálu
  console.log('\n1. Test filtrovania podľa kvartálu (Q1 2024):');
  const q1Collections = filterCollectionsByQuarter(mockVyvozy, 1, 2024);
  console.log(`Nájdených vývozov: ${q1Collections.length} (očakávané: 4)`);
  if (q1Collections.length === 4) console.log('✅ OK'); else console.log('❌ CHYBA');

  // 2. Test výpočtu bodov (simulácia triggeru)
  console.log('\n2. Test výpočtu bodov (simulácia):');
  let totalPoints = 0;
  q1Collections.forEach(v => {
    if (v.typ_odpadu !== 'zmesovy') {
      totalPoints += Number(v.mnozstvo_kg) * 2;
    }
  });
  console.log(`Celkové body za Q1: ${totalPoints} (očakávané: (10.5+5.0+8.2)*2 = 47.4)`);
  if (Math.abs(totalPoints - 47.4) < 0.01) console.log('✅ OK'); else console.log('❌ CHYBA');

  // 3. Test generovania XML reportu (Legislatívna zhoda)
  console.log('\n3. Test generovania XML reportu (ISOH):');
  try {
    const xmlReport = await generateXMLReport(mockObec, q1Collections, 1, 2024);
    console.log('XML report vygenerovaný úspešne.');
    
    // Kontrola kľúčových polí v XML
    const checks = [
      { label: 'IČO', pattern: `<ICO>${mockObec.ico}</ICO>` },
      { label: 'Kvartál', pattern: `<Kvartal>1</Kvartal>` },
      { label: 'Kód odpadu (Plast)', pattern: `<KodOdpadu>20 01 39</KodOdpadu>` },
      { label: 'Kód nakladania', pattern: `<KodNakladania>OO</KodNakladania>` },
      { label: 'Množstvo (Plast)', pattern: `<MnozstvoKG>10.50</MnozstvoKG>` }
    ];

    checks.forEach(check => {
      if (xmlReport.includes(check.pattern)) {
        console.log(`✅ XML obsahuje ${check.label}`);
      } else {
        console.log(`❌ XML neobsahuje ${check.label}`);
      }
    });
  } catch (err) {
    console.error('❌ Chyba pri generovaní XML:', err);
  }

  // 4. Test generovania CSV reportu
  console.log('\n4. Test generovania CSV reportu:');
  try {
    const csvReport = await generateCSVReport(mockObec, q1Collections, 1, 2024);
    console.log('CSV report vygenerovaný úspešne.');
    if (csvReport.includes('20 01 39') && csvReport.includes('10.50')) {
      console.log('✅ CSV obsahuje správne dáta');
    } else {
      console.log('❌ CSV neobsahuje správne dáta');
    }
  } catch (err) {
    console.error('❌ Chyba pri generovaní CSV:', err);
  }

  console.log('\n--- 🏁 KONIEC TESTOVANIA ---');
}

runTests();
