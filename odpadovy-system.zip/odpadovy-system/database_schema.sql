-- =====================================================
-- OBECNÝ ODPADOVÝ SYSTÉM - DATABASE SCHEMA
-- =====================================================
-- This script creates all necessary tables for the waste management system
-- Run this in your Supabase SQL Editor

-- =====================================================
-- 1. OBCE (Municipalities) Table
-- =====================================================
CREATE TABLE IF NOT EXISTS obce (
  id BIGSERIAL PRIMARY KEY,
  auth_user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  nazov TEXT NOT NULL,
  email TEXT NOT NULL,
  ico TEXT,
  ulica TEXT,
  mesto TEXT,
  psc TEXT,
  velkost_obce TEXT CHECK (velkost_obce IN ('mala', 'stredna', 'velka')),
  subscription_status TEXT DEFAULT 'trial' CHECK (subscription_status IN ('trial', 'active', 'expired', 'cancelled')),
  trial_start TIMESTAMPTZ DEFAULT NOW(),
  trial_end TIMESTAMPTZ DEFAULT (NOW() + INTERVAL '30 days'),
  stripe_customer_id TEXT,
  stripe_subscription_id TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(auth_user_id),
  UNIQUE(email)
);

-- =====================================================
-- 2. OBYVATELIA (Residents) Table
-- =====================================================
CREATE TABLE IF NOT EXISTS obyvatelia (
  id BIGSERIAL PRIMARY KEY,
  obec_id BIGINT REFERENCES obce(id) ON DELETE CASCADE,
  meno TEXT NOT NULL,
  priezvisko TEXT NOT NULL,
  ulica TEXT,
  cislo_popisne TEXT,
  celkove_body BIGINT DEFAULT 0,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- 3. VYVOZY (Waste Collections) Table
-- =====================================================
CREATE TABLE IF NOT EXISTS vyvozy (
  id BIGSERIAL PRIMARY KEY,
  obec_id BIGINT REFERENCES obce(id) ON DELETE CASCADE,
  obyvatel_id BIGINT REFERENCES obyvatelia(id) ON DELETE CASCADE,
  datum DATE NOT NULL,
  typ_odpadu TEXT NOT NULL CHECK (typ_odpadu IN ('plast', 'papier', 'sklo', 'zmesovy')),
  mnozstvo_kg DECIMAL(10,2) NOT NULL,
  kod_odpadu TEXT NOT NULL,
  kod_nakladania TEXT DEFAULT 'OO',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- 4. ODMENY (Rewards) Table
-- =====================================================
CREATE TABLE IF NOT EXISTS odmeny (
  id BIGSERIAL PRIMARY KEY,
  obec_id BIGINT REFERENCES obce(id) ON DELETE CASCADE,
  nazov TEXT NOT NULL,
  popis TEXT,
  cena_v_bodoch BIGINT NOT NULL,
  obrazok_url TEXT,
  stav TEXT DEFAULT 'aktivna' CHECK (stav IN ('aktivna', 'neaktivna')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- 5. HARMONOGRAM (Collection Schedule) Table
-- =====================================================
CREATE TABLE IF NOT EXISTS harmonogram (
  id BIGSERIAL PRIMARY KEY,
  obec_id BIGINT REFERENCES obce(id) ON DELETE CASCADE,
  datum DATE NOT NULL,
  typ_odpadu TEXT NOT NULL,
  poznamka TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(obec_id, datum, typ_odpadu)
);

-- =====================================================
-- 6. REPORTY (Reports) Table
-- =====================================================
CREATE TABLE IF NOT EXISTS reporty (
  id BIGSERIAL PRIMARY KEY,
  obec_id BIGINT REFERENCES obce(id) ON DELETE CASCADE,
  kvartal INT NOT NULL CHECK (kvartal BETWEEN 1 AND 4),
  rok INT NOT NULL,
  subor_csv TEXT,
  subor_xml TEXT,
  subor_xlsx TEXT,
  vygenerovane_dna TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(obec_id, kvartal, rok)
);

-- =====================================================
-- 7. INDEXES for Performance
-- =====================================================
CREATE INDEX IF NOT EXISTS idx_obce_auth_user_id ON obce(auth_user_id);
CREATE INDEX IF NOT EXISTS idx_obyvatelia_obec_id ON obyvatelia(obec_id);
CREATE INDEX IF NOT EXISTS idx_obyvatelia_user_id ON obyvatelia(user_id);
CREATE INDEX IF NOT EXISTS idx_vyvozy_obec_id ON vyvozy(obec_id);
CREATE INDEX IF NOT EXISTS idx_vyvozy_obyvatel_id ON vyvozy(obyvatel_id);
CREATE INDEX IF NOT EXISTS idx_vyvozy_datum ON vyvozy(datum);
CREATE INDEX IF NOT EXISTS idx_odmeny_obec_id ON odmeny(obec_id);
CREATE INDEX IF NOT EXISTS idx_harmonogram_obec_id ON harmonogram(obec_id);
CREATE INDEX IF NOT EXISTS idx_harmonogram_datum ON harmonogram(datum);
CREATE INDEX IF NOT EXISTS idx_reporty_obec_id ON reporty(obec_id);

-- =====================================================
-- 8. ROW LEVEL SECURITY (RLS) POLICIES
-- =====================================================

-- Enable RLS on all tables
ALTER TABLE obce ENABLE ROW LEVEL SECURITY;
ALTER TABLE obyvatelia ENABLE ROW LEVEL SECURITY;
ALTER TABLE vyvozy ENABLE ROW LEVEL SECURITY;
ALTER TABLE odmeny ENABLE ROW LEVEL SECURITY;
ALTER TABLE harmonogram ENABLE ROW LEVEL SECURITY;
ALTER TABLE reporty ENABLE ROW LEVEL SECURITY;

-- OBCE Policies (Municipality can only see their own data)
CREATE POLICY "Obce can view own data" ON obce
  FOR SELECT USING (auth.uid() = auth_user_id);

CREATE POLICY "Obce can update own data" ON obce
  FOR UPDATE USING (auth.uid() = auth_user_id);

CREATE POLICY "Users can insert their municipality" ON obce
  FOR INSERT WITH CHECK (auth.uid() = auth_user_id);

-- OBYVATELIA Policies (Municipality can manage their residents)
CREATE POLICY "Obce can view own residents" ON obyvatelia
  FOR SELECT USING (
    obec_id IN (SELECT id FROM obce WHERE auth_user_id = auth.uid())
  );

CREATE POLICY "Obce can insert own residents" ON obyvatelia
  FOR INSERT WITH CHECK (
    obec_id IN (SELECT id FROM obce WHERE auth_user_id = auth.uid())
  );

CREATE POLICY "Obce can update own residents" ON obyvatelia
  FOR UPDATE USING (
    obec_id IN (SELECT id FROM obce WHERE auth_user_id = auth.uid())
  );

CREATE POLICY "Obce can delete own residents" ON obyvatelia
  FOR DELETE USING (
    obec_id IN (SELECT id FROM obce WHERE auth_user_id = auth.uid())
  );

-- Citizens can view their own data
CREATE POLICY "Citizens can view own data" ON obyvatelia
  FOR SELECT USING (auth.uid() = user_id);

-- VYVOZY Policies (Municipality can manage their waste collections)
CREATE POLICY "Obce can view own collections" ON vyvozy
  FOR SELECT USING (
    obec_id IN (SELECT id FROM obce WHERE auth_user_id = auth.uid())
  );

CREATE POLICY "Obce can insert own collections" ON vyvozy
  FOR INSERT WITH CHECK (
    obec_id IN (SELECT id FROM obce WHERE auth_user_id = auth.uid())
  );

CREATE POLICY "Obce can update own collections" ON vyvozy
  FOR UPDATE USING (
    obec_id IN (SELECT id FROM obce WHERE auth_user_id = auth.uid())
  );

CREATE POLICY "Obce can delete own collections" ON vyvozy
  FOR DELETE USING (
    obec_id IN (SELECT id FROM obce WHERE auth_user_id = auth.uid())
  );

-- ODMENY Policies (Municipality can manage their rewards)
CREATE POLICY "Obce can view own rewards" ON odmeny
  FOR SELECT USING (
    obec_id IN (SELECT id FROM obce WHERE auth_user_id = auth.uid())
  );

CREATE POLICY "Obce can insert own rewards" ON odmeny
  FOR INSERT WITH CHECK (
    obec_id IN (SELECT id FROM obce WHERE auth_user_id = auth.uid())
  );

CREATE POLICY "Obce can update own rewards" ON odmeny
  FOR UPDATE USING (
    obec_id IN (SELECT id FROM obce WHERE auth_user_id = auth.uid())
  );

CREATE POLICY "Obce can delete own rewards" ON odmeny
  FOR DELETE USING (
    obec_id IN (SELECT id FROM obce WHERE auth_user_id = auth.uid())
  );

-- Citizens can view active rewards from their municipality
CREATE POLICY "Citizens can view rewards" ON odmeny
  FOR SELECT USING (
    stav = 'aktivna' AND 
    obec_id IN (SELECT obec_id FROM obyvatelia WHERE user_id = auth.uid())
  );

-- HARMONOGRAM Policies (Municipality can manage their schedule)
CREATE POLICY "Obce can view own schedule" ON harmonogram
  FOR SELECT USING (
    obec_id IN (SELECT id FROM obce WHERE auth_user_id = auth.uid())
  );

CREATE POLICY "Obce can insert own schedule" ON harmonogram
  FOR INSERT WITH CHECK (
    obec_id IN (SELECT id FROM obce WHERE auth_user_id = auth.uid())
  );

CREATE POLICY "Obce can update own schedule" ON harmonogram
  FOR UPDATE USING (
    obec_id IN (SELECT id FROM obce WHERE auth_user_id = auth.uid())
  );

CREATE POLICY "Obce can delete own schedule" ON harmonogram
  FOR DELETE USING (
    obec_id IN (SELECT id FROM obce WHERE auth_user_id = auth.uid())
  );

-- Citizens can view schedule from their municipality
CREATE POLICY "Citizens can view schedule" ON harmonogram
  FOR SELECT USING (
    obec_id IN (SELECT obec_id FROM obyvatelia WHERE user_id = auth.uid())
  );

-- REPORTY Policies (Municipality can manage their reports)
CREATE POLICY "Obce can view own reports" ON reporty
  FOR SELECT USING (
    obec_id IN (SELECT id FROM obce WHERE auth_user_id = auth.uid())
  );

CREATE POLICY "Obce can insert own reports" ON reporty
  FOR INSERT WITH CHECK (
    obec_id IN (SELECT id FROM obce WHERE auth_user_id = auth.uid())
  );

CREATE POLICY "Obce can update own reports" ON reporty
  FOR UPDATE USING (
    obec_id IN (SELECT id FROM obce WHERE auth_user_id = auth.uid())
  );

CREATE POLICY "Obce can delete own reports" ON reporty
  FOR DELETE USING (
    obec_id IN (SELECT id FROM obce WHERE auth_user_id = auth.uid())
  );

-- =====================================================
-- 9. TRIGGER for Automatic Points Calculation
-- =====================================================

-- Function to calculate and update points
CREATE OR REPLACE FUNCTION update_obyvatel_body()
RETURNS TRIGGER AS $$
BEGIN
  -- Calculate points: 2 points per kg for plast, papier, sklo; 0 for zmesovy
  IF NEW.typ_odpadu IN ('plast', 'papier', 'sklo') THEN
    UPDATE obyvatelia
    SET celkove_body = celkove_body + (NEW.mnozstvo_kg * 2)
    WHERE id = NEW.obyvatel_id;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to update points after insert
CREATE TRIGGER trigger_update_body_after_vyvoz
AFTER INSERT ON vyvozy
FOR EACH ROW
EXECUTE FUNCTION update_obyvatel_body();

-- Function to recalculate points when collection is deleted
CREATE OR REPLACE FUNCTION recalculate_body_on_delete()
RETURNS TRIGGER AS $$
BEGIN
  -- Subtract points when collection is deleted
  IF OLD.typ_odpadu IN ('plast', 'papier', 'sklo') THEN
    UPDATE obyvatelia
    SET celkove_body = GREATEST(0, celkove_body - (OLD.mnozstvo_kg * 2))
    WHERE id = OLD.obyvatel_id;
  END IF;
  
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;

-- Trigger to recalculate points after delete
CREATE TRIGGER trigger_recalculate_body_after_delete
AFTER DELETE ON vyvozy
FOR EACH ROW
EXECUTE FUNCTION recalculate_body_on_delete();

-- Function to handle points update when collection is modified
CREATE OR REPLACE FUNCTION update_body_on_update()
RETURNS TRIGGER AS $$
BEGIN
  -- Remove old points
  IF OLD.typ_odpadu IN ('plast', 'papier', 'sklo') THEN
    UPDATE obyvatelia
    SET celkove_body = GREATEST(0, celkove_body - (OLD.mnozstvo_kg * 2))
    WHERE id = OLD.obyvatel_id;
  END IF;
  
  -- Add new points
  IF NEW.typ_odpadu IN ('plast', 'papier', 'sklo') THEN
    UPDATE obyvatelia
    SET celkove_body = celkove_body + (NEW.mnozstvo_kg * 2)
    WHERE id = NEW.obyvatel_id;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to update points after update
CREATE TRIGGER trigger_update_body_on_update
AFTER UPDATE ON vyvozy
FOR EACH ROW
WHEN (OLD.mnozstvo_kg IS DISTINCT FROM NEW.mnozstvo_kg OR OLD.typ_odpadu IS DISTINCT FROM NEW.typ_odpadu OR OLD.obyvatel_id IS DISTINCT FROM NEW.obyvatel_id)
EXECUTE FUNCTION update_body_on_update();

-- =====================================================
-- 10. FUNCTION to Set Waste Code Based on Type
-- =====================================================

-- Function to automatically set kod_odpadu based on typ_odpadu
CREATE OR REPLACE FUNCTION set_kod_odpadu()
RETURNS TRIGGER AS $$
BEGIN
  CASE NEW.typ_odpadu
    WHEN 'plast' THEN NEW.kod_odpadu := '20 01 39';
    WHEN 'papier' THEN NEW.kod_odpadu := '20 01 01';
    WHEN 'sklo' THEN NEW.kod_odpadu := '20 01 02';
    WHEN 'zmesovy' THEN NEW.kod_odpadu := '20 03 01';
  END CASE;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to set kod_odpadu before insert
CREATE TRIGGER trigger_set_kod_odpadu
BEFORE INSERT OR UPDATE ON vyvozy
FOR EACH ROW
EXECUTE FUNCTION set_kod_odpadu();

-- =====================================================
-- SCHEMA CREATION COMPLETE
-- =====================================================
-- Next steps:
-- 1. Copy your Supabase URL and anon key to .env.local
-- 2. Enable email authentication in Supabase Dashboard
-- 3. Configure Stripe webhooks
-- =====================================================
