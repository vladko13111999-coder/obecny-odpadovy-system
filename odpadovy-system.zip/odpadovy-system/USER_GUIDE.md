# 📖 Používateľská príručka - Obecný Odpadový Systém

Kompletný návod na používanie aplikácie pre starostov a občanov.

---

## 👨‍💼 Pre starostov

### 1️⃣ Registrácia a prihlásenie

#### Registrácia obce

1. Otvorte aplikáciu
2. Kliknite na **"Registrovať obec"**
3. Vyplňte formulár:
   - Email (bude slúžiť ako prihlasovacie meno)
   - Heslo (min. 6 znakov)
   - Názov obce
   - Veľkosť obce (malá/stredná/veľká)
4. Kliknite **"Registrovať"**
5. Automaticky dostanete **30-dňový trial** zadarmo

#### Prihlásenie

1. Kliknite na **"Prihlásiť sa"**
2. Zadajte email a heslo
3. Kliknite **"Prihlásiť"**

---

### 2️⃣ Dashboard

Po prihlásení uvidíte hlavný dashboard so štatistikami:

- **Počet obyvateľov** - Celkový počet registrovaných obyvateľov
- **Počet vývozov** - Celkový počet zaznamenaných vývozov
- **Celkové body** - Súčet bodov všetkých obyvateľov
- **Celkové množstvo** - Celkové množstvo odpadu v kg

Dashboard obsahuje aj:
- **Graf odpadu podľa typu** (bar chart)
- **Rozdelenie odpadu** (pie chart)
- **Posledných 5 vývozov** (tabuľka)

---

### 3️⃣ Správa obyvateľov

#### Pridanie obyvateľa

1. V menu kliknite na **"Obyvatelia"**
2. Kliknite **"+ Pridať obyvateľa"**
3. Vyplňte formulár:
   - Meno *
   - Priezvisko *
   - Email *
   - Telefón
   - Ulica
   - Číslo popisné
4. Kliknite **"Pridať"**
5. **DÔLEŽITÉ:** Poznačte si **ID obyvateľa** - bude ho potrebovať pri registrácii

#### Úprava obyvateľa

1. V zozname obyvateľov kliknite **"Upraviť"**
2. Zmeňte potrebné údaje
3. Kliknite **"Uložiť"**

#### Zmazanie obyvateľa

1. V zozname obyvateľov kliknite **"Zmazať"**
2. Potvrďte zmazanie

#### Vyhľadávanie

- Použite vyhľadávacie pole na filtrovanie obyvateľov podľa mena alebo priezviska

---

### 4️⃣ Evidencia vývozov

#### Pridanie vývozu

1. V menu kliknite na **"Vývozy"**
2. Kliknite **"+ Pridať vývoz"**
3. Vyplňte formulár:
   - Obyvateľ * (vyberte zo zoznamu)
   - Dátum *
   - Typ odpadu * (plast/papier/sklo/zmesový)
   - Množstvo v kg *
4. Systém automaticky vypočíta body:
   - **Plast, papier, sklo:** 2 body/kg
   - **Zmesový odpad:** 0 bodov/kg
5. Kliknite **"Pridať"**

#### Filtrovanie vývozov

- **Podľa typu odpadu:** Vyberte typ z dropdown menu
- **Podľa mesiaca:** Vyberte mesiac z kalendára
- **Zrušiť filtre:** Kliknite "Zrušiť filtre"

#### Úprava/Zmazanie vývozu

- Kliknite **"Upraviť"** alebo **"Zmazať"** pri konkrétnom vývozе

---

### 5️⃣ Generovanie reportov

#### Vytvorenie reportu

1. V menu kliknite na **"Reporty"**
2. Vyberte:
   - **Kvartál** (Q1/Q2/Q3/Q4)
   - **Rok**
3. Kliknite **"Vygenerovať report"**
4. Systém vytvorí 3 formáty:
   - **XML** - Pre nahratie do ISOH
   - **CSV** - Pre import do Excelu
   - **XLSX** - Excel súbor s formátovaním

#### Stiahnutie reportu

1. V zozname reportov kliknite na požadovaný formát:
   - 📄 **XML** - Pre ISOH
   - 📊 **CSV** - Pre analýzu
   - 📈 **XLSX** - Pre tlač

#### Katalógové čísla odpadu

Systém automaticky priradí správne kódy podľa vyhlášky č. 366/2015 Z.z.:

| Typ odpadu | Kód odpadu |
|------------|------------|
| Plast      | 20 01 39   |
| Papier     | 20 01 01   |
| Sklo       | 20 01 02   |
| Zmesový    | 20 03 01   |

**Kód nakladania:** OO (odovzdanie obchodníkovi)

---

### 6️⃣ Správa odmien

#### Pridanie odmeny

1. V menu kliknite na **"Odmeny"**
2. Kliknite **"+ Pridať odmenu"**
3. Vyplňte formulár:
   - Názov * (napr. "Zľava 10% v kaviarni")
   - Popis (voliteľné)
   - Cena v bodoch *
   - URL obrázka (voliteľné)
   - Stav (aktívna/neaktívna)
4. Kliknite **"Pridať"**

#### Úprava odmeny

1. Na karte odmeny kliknite **"Upraviť"**
2. Zmeňte údaje
3. Kliknite **"Uložiť"**

#### Deaktivácia odmeny

- Kliknite **"Deaktivovať"** - odmena sa prestane zobrazovať občanom
- Kliknite **"Aktivovať"** - odmena sa opäť zobrazí

#### Zmazanie odmeny

- Kliknite **"Zmazať"** a potvrďte

---

### 7️⃣ Kalendár vývozov

#### Pridanie vývozu do kalendára

1. V menu kliknite na **"Harmonogram"**
2. Kliknite na požadovaný dátum v kalendári
3. Vyplňte formulár:
   - Dátum *
   - Typ odpadu *
   - Poznámka (napr. "Vývoz o 7:00 ráno")
4. Kliknite **"Pridať"**

#### Zobrazenie vývozov

- **Kalendár:** Vývozy sú farebne označené podľa typu odpadu
- **Zoznam:** Nadchádzajúce vývozy sú zobrazené v tabuľke

#### Zmazanie vývozu

- Kliknite **"Zmazať"** pri konkrétnom vývozе

---

### 8️⃣ Predplatné a platby

#### Aktivácia predplatného

1. V menu kliknite na **"Nastavenia"**
2. V sekcii "Predplatné" kliknite **"Aktivovať predplatné"**
3. Budete presmerovaní na Stripe platobný formulár
4. Vyplňte platobné údaje
5. Po úspešnej platbe sa váš stav zmení na **"Aktívne"**

#### Cenník

| Veľkosť obce | Cena |
|--------------|------|
| Malá (do 1000) | 49 €/mesiac |
| Stredná (1000-5000) | 99 €/mesiac |
| Veľká (nad 5000) | 149 €/mesiac |

#### Trial obdobie

- **Trvanie:** 30 dní od registrácie
- **Funkcie:** Plný prístup ku všetkým funkciám
- **Po skončení:** Potrebné aktivovať predplatné

---

### 9️⃣ Nastavenia profilu

1. V menu kliknite na **"Nastavenia"**
2. V sekcii "Profil obce" môžete upraviť:
   - Názov obce
   - IČO
   - Ulica
   - Mesto
   - PSČ
3. Kliknite **"Uložiť zmeny"**

**Poznámka:** Email nie je možné zmeniť.

---

## 👥 Pre občanov

### 1️⃣ Registrácia

1. Otvorte aplikáciu
2. Kliknite na **"Registrácia občana"**
3. **Krok 1:** Zadajte overovací kód
   - Overovací kód = **ID obyvateľa** (dostanete od starostu)
4. **Krok 2:** Vytvorte si heslo
   - Heslo (min. 6 znakov)
   - Potvrdenie hesla
5. Kliknite **"Dokončiť registráciu"**

### 2️⃣ Prihlásenie

1. Kliknite na **"Prihlásiť sa"**
2. Zadajte:
   - Email (ktorý vám pridelil starosta)
   - Heslo
3. Kliknite **"Prihlásiť"**

---

### 3️⃣ Dashboard

Po prihlásení uvidíte váš prehľad:

- **Celkové body** - Vaše nazbierané body
- **Počet vývozov** - Koľkokrát ste odovzdali odpad
- **Celkové množstvo** - Celkové kg odpadu
- **Vaše poradie** - Pozícia v rebríčku

Dashboard obsahuje aj:
- **Tabuľku vašich posledných vývozov**
- **Motivačnú sekciu** s odkazmi na odmeny a rebríček

---

### 4️⃣ Rebríček

1. V menu kliknite na **"Rebríček"**
2. Uvidíte zoznam všetkých obyvateľov zoradených podľa bodov:
   - 🥇 1. miesto - zlatá medaila
   - 🥈 2. miesto - strieborná medaila
   - 🥉 3. miesto - bronzová medaila
3. Váš riadok je zvýraznený modrou farbou

#### Ako získať viac bodov?

- Trieďte odpad pravidelne
- Za každý kg plastu, papiera alebo skla získate **2 body**
- Čím viac triedite, tým vyššie sa dostanete v rebríčku

---

### 5️⃣ Obchodík s odmenami

1. V menu kliknite na **"Obchodík"**
2. Uvidíte všetky dostupné odmeny
3. Odmeny, na ktoré máte dostatok bodov, majú zelené tlačidlo **"Získať odmenu"**
4. Odmeny, na ktoré nemáte dostatok bodov, sú označené šedou farbou

#### Získanie odmeny

1. Kliknite **"Získať odmenu"**
2. Zobrazí sa potvrdenie
3. Kontaktujte starostu pre vyzdvihnutie odmeny

**Poznámka:** V budúcnosti bude tento proces automatizovaný.

---

### 6️⃣ Kalendár vývozov

1. V menu kliknite na **"Kalendár"**
2. Uvidíte:
   - **Kalendár** s farebne označenými vývozmi
   - **Detail vybraného dňa** vpravo
   - **Zoznam nadchádzajúcich vývozov** dole

#### Príprava na vývoz

- Sledujte kalendár
- Pripravte si odpad podľa typu
- Odpad vyložte v čase uvedenom v poznámke

---

## 🎯 Tipy a triky

### Pre starostov

1. **Pravidelne aktualizujte kalendár** - Obyvatelia sa budú lepšie pripravovať
2. **Vytvárajte atraktívne odmeny** - Zvýšite motiváciu obyvateľov
3. **Generujte reporty včas** - Kvartálne reporty vytvárajte na konci každého kvartálu
4. **Kontrolujte štatistiky** - Dashboard vám ukáže trendy v triedení

### Pre občanov

1. **Trieďte pravidelne** - Získate viac bodov
2. **Sledujte kalendár** - Nezmeškáte vývozy
3. **Súťažte s ostatnými** - Rebríček vás motivuje
4. **Šetrite body** - Na lepšie odmeny

---

## ❓ Často kladené otázky (FAQ)

### Pre starostov

**Q: Ako získam ID obyvateľa?**  
A: Po pridaní obyvateľa sa ID zobrazí v zozname obyvateľov. Skopírujte ho a pošlite obyvateľovi.

**Q: Môžem zmeniť veľkosť obce?**  
A: Nie, veľkosť obce sa nastavuje pri registrácii. Pre zmenu kontaktujte podporu.

**Q: Čo sa stane po skončení trial obdobia?**  
A: Budete vyzvaní na aktiváciu predplatného. Bez aktívneho predplatného stratíte prístup k aplikácii.

**Q: Môžem zmazať vývoz?**  
A: Áno, ale body sa automaticky odpočítajú obyvateľovi.

### Pre občanov

**Q: Zabudol som heslo, čo mám robiť?**  
A: Kontaktujte starostu obce, ktorý vám vytvorí nové prihlasovacie údaje.

**Q: Prečo nemám žiadne body?**  
A: Body získavate len za triedený odpad (plast, papier, sklo). Zmesový odpad body neprinášа.

**Q: Ako viem, kedy je vývoz?**  
A: Sledujte kalendár vývozov v menu "Kalendár".

---

## 📞 Podpora

Pre technické problémy alebo otázky kontaktujte:
- 📧 Email: support@odpadovy-system.sk
- 📚 Dokumentácia: README.md
- 🐛 Nahlásenie chyby: GitHub Issues

---

**Ďakujeme, že používate Obecný Odpadový Systém! 🌱**
