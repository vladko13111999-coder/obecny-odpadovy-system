import { useState } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';
import { createBrowserSupabaseClient } from '@/lib/supabase';

export default function LoginPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const supabase = createBrowserSupabaseClient();

      const { data, error: signInError } = await supabase.auth.signInWithPassword({
        email: formData.email,
        password: formData.password,
      });

      if (signInError) throw signInError;

      // Check if user is starosta or citizen
      const { data: obecData } = await supabase
        .from('obce')
        .select('id')
        .eq('auth_user_id', data.user.id)
        .single();

      if (obecData) {
        // User is starosta
        router.push('/dashboard');
      } else {
        // Check if user is citizen
        const { data: obyvatelData } = await supabase
          .from('obyvatelia')
          .select('id')
          .eq('user_id', data.user.id)
          .single();

        if (obyvatelData) {
          router.push('/citizen');
        } else {
          throw new Error('Používateľ nemá priradenú rolu');
        }
      }
    } catch (err: any) {
      console.error('Login error:', err);
      setError(err.message || 'Nesprávne prihlasovacie údaje');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8 bg-white p-8 rounded-lg shadow-lg">
        <div>
          <h2 className="text-center text-3xl font-bold text-gray-900">
            Prihlásenie
          </h2>
          <p className="mt-2 text-center text-sm text-gray-600">
            Obecný odpadový systém
          </p>
        </div>

        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
              {error}
            </div>
          )}

          <div className="space-y-4">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                Email
              </label>
              <input
                id="email"
                name="email"
                type="email"
                required
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                Heslo
              </label>
              <input
                id="password"
                name="password"
                type="password"
                required
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
              />
            </div>
          </div>

          <div>
            <button
              type="submit"
              disabled={loading}
              className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Prihlasovanie...' : 'Prihlásiť sa'}
            </button>
          </div>

          <div className="flex items-center justify-between text-sm">
            <Link href="/auth/register" className="text-green-600 hover:text-green-500">
              Registrovať obec
            </Link>
            <Link href="/auth/citizen-register" className="text-blue-600 hover:text-blue-500">
              Registrácia občana
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
}
