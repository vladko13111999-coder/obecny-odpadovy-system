import { useState } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';
import { createBrowserSupabaseClient } from '@/lib/supabase';

export default function CitizenRegisterPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [step, setStep] = useState<'code' | 'register'>('code');
  const [obyvatelId, setObyvatelId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    verificationCode: '',
    email: '',
    password: '',
    confirmPassword: '',
  });

  const handleVerifyCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const supabase = createBrowserSupabaseClient();

      // In a real implementation, you would store verification codes in a separate table
      // For now, we'll use a simple approach: verification code = obyvatel ID (6 digits)
      const code = formData.verificationCode.trim();
      
      if (!/^\d{6}$/.test(code)) {
        throw new Error('Overovací kód musí mať 6 číslic');
      }

      // Try to find obyvatel by ID (this is simplified - in production use a proper verification system)
      const { data: obyvatelData, error: obyvatelError } = await supabase
        .from('obyvatelia')
        .select('id, meno, priezvisko, user_id')
        .eq('id', parseInt(code))
        .is('user_id', null)
        .single();

      if (obyvatelError || !obyvatelData) {
        throw new Error('Neplatný overovací kód alebo účet už bol aktivovaný');
      }

      setObyvatelId(obyvatelData.id);
      setStep('register');
    } catch (err: any) {
      console.error('Verification error:', err);
      setError(err.message || 'Neplatný overovací kód');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    // Validation
    if (formData.password !== formData.confirmPassword) {
      setError('Heslá sa nezhodujú');
      setLoading(false);
      return;
    }

    if (formData.password.length < 6) {
      setError('Heslo musí mať aspoň 6 znakov');
      setLoading(false);
      return;
    }

    try {
      const supabase = createBrowserSupabaseClient();

      // 1. Create auth user
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password,
      });

      if (authError) throw authError;
      if (!authData.user) throw new Error('Používateľ nebol vytvorený');

      // 2. Link user to obyvatel record
      const { error: updateError } = await supabase
        .from('obyvatelia')
        .update({ user_id: authData.user.id })
        .eq('id', obyvatelId);

      if (updateError) throw updateError;

      // Success - redirect to citizen portal
      router.push('/citizen');
    } catch (err: any) {
      console.error('Registration error:', err);
      setError(err.message || 'Nastala chyba pri registrácii');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8 bg-white p-8 rounded-lg shadow-lg">
        <div>
          <h2 className="text-center text-3xl font-bold text-gray-900">
            Registrácia občana
          </h2>
          <p className="mt-2 text-center text-sm text-gray-600">
            {step === 'code' 
              ? 'Zadajte overovací kód, ktorý ste dostali od starostu'
              : 'Vytvorte si prihlasovacie údaje'}
          </p>
        </div>

        {step === 'code' ? (
          <form className="mt-8 space-y-6" onSubmit={handleVerifyCode}>
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
                {error}
              </div>
            )}

            <div>
              <label htmlFor="verificationCode" className="block text-sm font-medium text-gray-700">
                Overovací kód (6 číslic)
              </label>
              <input
                id="verificationCode"
                name="verificationCode"
                type="text"
                required
                maxLength={6}
                value={formData.verificationCode}
                onChange={(e) => setFormData({ ...formData, verificationCode: e.target.value })}
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-center text-2xl tracking-widest"
                placeholder="000000"
              />
              <p className="mt-2 text-xs text-gray-500">
                Overovací kód nájdete v zozname obyvateľov vo vašej obci (ID obyvateľa)
              </p>
            </div>

            <div>
              <button
                type="submit"
                disabled={loading}
                className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? 'Overujem...' : 'Overiť kód'}
              </button>
            </div>

            <div className="text-center">
              <Link href="/auth/login" className="text-sm text-blue-600 hover:text-blue-500">
                Už máte účet? Prihláste sa
              </Link>
            </div>
          </form>
        ) : (
          <form className="mt-8 space-y-6" onSubmit={handleRegister}>
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
                {error}
              </div>
            )}

            <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded">
              ✓ Overovací kód bol úspešne overený
            </div>

            <div className="space-y-4">
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                  Email *
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              <div>
                <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                  Heslo *
                </label>
                <input
                  id="password"
                  name="password"
                  type="password"
                  required
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              <div>
                <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700">
                  Potvrdenie hesla *
                </label>
                <input
                  id="confirmPassword"
                  name="confirmPassword"
                  type="password"
                  required
                  value={formData.confirmPassword}
                  onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            </div>

            <div>
              <button
                type="submit"
                disabled={loading}
                className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? 'Registrujem...' : 'Dokončiť registráciu'}
              </button>
            </div>

            <div className="text-center">
              <button
                type="button"
                onClick={() => setStep('code')}
                className="text-sm text-gray-600 hover:text-gray-500"
              >
                ← Späť na zadanie kódu
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
