import { useState } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';
import { createBrowserSupabaseClient } from '@/lib/supabase';
import { VelkostObce } from '@/types/database';

export default function RegisterPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    nazov: '',
    email: '',
    password: '',
    confirmPassword: '',
    ico: '',
    ulica: '',
    mesto: '',
    psc: '',
    velkost_obce: 'mala' as VelkostObce,
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    // Validation
    if (formData.password !== formData.confirmPassword) {
      setError('Heslá sa nezhodujú');
      setLoading(false);
      return;
    }

    if (formData.password.length < 6) {
      setError('Heslo musí mať aspoň 6 znakov');
      setLoading(false);
      return;
    }

    try {
      const supabase = createBrowserSupabaseClient();

      // 1. Create auth user
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password,
      });

      if (authError) throw authError;
      if (!authData.user) throw new Error('Používateľ nebol vytvorený');

      // 2. Create obec record
      const { error: obecError } = await supabase.from('obce').insert({
        auth_user_id: authData.user.id,
        nazov: formData.nazov,
        email: formData.email,
        ico: formData.ico || null,
        ulica: formData.ulica || null,
        mesto: formData.mesto || null,
        psc: formData.psc || null,
        velkost_obce: formData.velkost_obce,
        subscription_status: 'trial',
        trial_start: new Date().toISOString(),
        trial_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days
      });

      if (obecError) throw obecError;

      // Success - redirect to dashboard
      router.push('/dashboard');
    } catch (err: any) {
      console.error('Registration error:', err);
      setError(err.message || 'Nastala chyba pri registrácii');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8 bg-white p-8 rounded-lg shadow-lg">
        <div>
          <h2 className="text-center text-3xl font-bold text-gray-900">
            Registrácia obce
          </h2>
          <p className="mt-2 text-center text-sm text-gray-600">
            Začnite s 30-dňovým skúšobným obdobím zadarmo
          </p>
        </div>

        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
              {error}
            </div>
          )}

          <div className="space-y-4">
            {/* Názov obce */}
            <div>
              <label htmlFor="nazov" className="block text-sm font-medium text-gray-700">
                Názov obce *
              </label>
              <input
                id="nazov"
                name="nazov"
                type="text"
                required
                value={formData.nazov}
                onChange={(e) => setFormData({ ...formData, nazov: e.target.value })}
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
              />
            </div>

            {/* Email */}
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                Email *
              </label>
              <input
                id="email"
                name="email"
                type="email"
                required
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
              />
            </div>

            {/* IČO */}
            <div>
              <label htmlFor="ico" className="block text-sm font-medium text-gray-700">
                IČO
              </label>
              <input
                id="ico"
                name="ico"
                type="text"
                value={formData.ico}
                onChange={(e) => setFormData({ ...formData, ico: e.target.value })}
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
              />
            </div>

            {/* Adresa */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label htmlFor="ulica" className="block text-sm font-medium text-gray-700">
                  Ulica
                </label>
                <input
                  id="ulica"
                  name="ulica"
                  type="text"
                  value={formData.ulica}
                  onChange={(e) => setFormData({ ...formData, ulica: e.target.value })}
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
                />
              </div>
              <div>
                <label htmlFor="mesto" className="block text-sm font-medium text-gray-700">
                  Mesto
                </label>
                <input
                  id="mesto"
                  name="mesto"
                  type="text"
                  value={formData.mesto}
                  onChange={(e) => setFormData({ ...formData, mesto: e.target.value })}
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
                />
              </div>
            </div>

            <div>
              <label htmlFor="psc" className="block text-sm font-medium text-gray-700">
                PSČ
              </label>
              <input
                id="psc"
                name="psc"
                type="text"
                value={formData.psc}
                onChange={(e) => setFormData({ ...formData, psc: e.target.value })}
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
              />
            </div>

            {/* Veľkosť obce */}
            <div>
              <label htmlFor="velkost_obce" className="block text-sm font-medium text-gray-700">
                Veľkosť obce *
              </label>
              <select
                id="velkost_obce"
                name="velkost_obce"
                required
                value={formData.velkost_obce}
                onChange={(e) => setFormData({ ...formData, velkost_obce: e.target.value as VelkostObce })}
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
              >
                <option value="mala">Malá obec (49 €/mesiac)</option>
                <option value="stredna">Stredná obec (99 €/mesiac)</option>
                <option value="velka">Veľká obec (149 €/mesiac)</option>
              </select>
            </div>

            {/* Heslo */}
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                Heslo *
              </label>
              <input
                id="password"
                name="password"
                type="password"
                required
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
              />
            </div>

            {/* Potvrdenie hesla */}
            <div>
              <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700">
                Potvrdenie hesla *
              </label>
              <input
                id="confirmPassword"
                name="confirmPassword"
                type="password"
                required
                value={formData.confirmPassword}
                onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
              />
            </div>
          </div>

          <div>
            <button
              type="submit"
              disabled={loading}
              className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Registrujem...' : 'Registrovať'}
            </button>
          </div>

          <div className="text-center">
            <Link href="/auth/login" className="text-sm text-green-600 hover:text-green-500">
              Už máte účet? Prihláste sa
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
}
