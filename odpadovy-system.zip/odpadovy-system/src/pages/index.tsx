import Link from 'next/link';
import { SUBSCRIPTION_PRICES } from '@/types/database';

export default function HomePage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-green-600 to-blue-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <h1 className="text-5xl font-bold mb-6">
              Obecný odpadový systém
            </h1>
            <p className="text-xl mb-8 text-green-100">
              Moderné riešenie pre evidenciu odpadu, motiváciu obyvateľov a reporting pre ISOH
            </p>
            <div className="flex justify-center gap-4">
              <Link
                href="/auth/register"
                className="bg-white text-green-600 px-8 py-3 rounded-lg font-semibold hover:bg-green-50 transition"
              >
                Začať zadarmo
              </Link>
              <Link
                href="/auth/login"
                className="bg-green-700 text-white px-8 py-3 rounded-lg font-semibold hover:bg-green-800 transition"
              >
                Prihlásiť sa
              </Link>
            </div>
            <p className="mt-4 text-sm text-green-100">
              ✓ 30 dní zadarmo, bez kreditnej karty
            </p>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h2 className="text-3xl font-bold text-center mb-12">Funkcie</h2>
        
        <div className="grid md:grid-cols-3 gap-8">
          <div className="p-6 border rounded-lg">
            <div className="text-4xl mb-4">📊</div>
            <h3 className="text-xl font-semibold mb-2">Evidencia odpadu</h3>
            <p className="text-gray-600">
              Jednoduchá evidencia vývozov odpadu s automatickým bodovaním obyvateľov
            </p>
          </div>

          <div className="p-6 border rounded-lg">
            <div className="text-4xl mb-4">📋</div>
            <h3 className="text-xl font-semibold mb-2">ISOH reporty</h3>
            <p className="text-gray-600">
              Automatické generovanie XML/CSV reportov podľa vyhlášky č. 366/2015 Z.z.
            </p>
          </div>

          <div className="p-6 border rounded-lg">
            <div className="text-4xl mb-4">🎮</div>
            <h3 className="text-xl font-semibold mb-2">Gamifikácia</h3>
            <p className="text-gray-600">
              Motivujte obyvateľov k triedeniu pomocou bodov, rebríčkov a odmien
            </p>
          </div>

          <div className="p-6 border rounded-lg">
            <div className="text-4xl mb-4">👥</div>
            <h3 className="text-xl font-semibold mb-2">Správa obyvateľov</h3>
            <p className="text-gray-600">
              Kompletná databáza obyvateľov s prehľadom ich aktivít a bodov
            </p>
          </div>

          <div className="p-6 border rounded-lg">
            <div className="text-4xl mb-4">📅</div>
            <h3 className="text-xl font-semibold mb-2">Kalendár vývozov</h3>
            <p className="text-gray-600">
              Prehľadný harmonogram zvozu odpadu dostupný pre všetkých obyvateľov
            </p>
          </div>

          <div className="p-6 border rounded-lg">
            <div className="text-4xl mb-4">🎁</div>
            <h3 className="text-xl font-semibold mb-2">Obchodík s odmenami</h3>
            <p className="text-gray-600">
              Obyvatelia môžu minúť nazbierané body na odmeny vytvorené starostom
            </p>
          </div>
        </div>
      </div>

      {/* Pricing Section */}
      <div className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Cenové plány</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-lg shadow-lg border-2 border-gray-200">
              <h3 className="text-2xl font-bold mb-2">Malá obec</h3>
              <p className="text-gray-600 mb-4">Do 1000 obyvateľov</p>
              <div className="text-4xl font-bold mb-6">
                {SUBSCRIPTION_PRICES.mala} €<span className="text-lg text-gray-600">/mesiac</span>
              </div>
              <ul className="space-y-2 mb-8">
                <li className="flex items-center">
                  <span className="text-green-500 mr-2">✓</span>
                  Neobmedzený počet obyvateľov
                </li>
                <li className="flex items-center">
                  <span className="text-green-500 mr-2">✓</span>
                  Všetky funkcie
                </li>
                <li className="flex items-center">
                  <span className="text-green-500 mr-2">✓</span>
                  ISOH reporty
                </li>
                <li className="flex items-center">
                  <span className="text-green-500 mr-2">✓</span>
                  30 dní zadarmo
                </li>
              </ul>
              <Link
                href="/auth/register"
                className="block w-full text-center bg-gray-200 text-gray-800 px-6 py-3 rounded-lg font-semibold hover:bg-gray-300 transition"
              >
                Začať
              </Link>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-lg border-2 border-green-500 relative">
              <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-green-500 text-white px-4 py-1 rounded-full text-sm font-semibold">
                Najpopulárnejšie
              </div>
              <h3 className="text-2xl font-bold mb-2">Stredná obec</h3>
              <p className="text-gray-600 mb-4">1000-5000 obyvateľov</p>
              <div className="text-4xl font-bold mb-6">
                {SUBSCRIPTION_PRICES.stredna} €<span className="text-lg text-gray-600">/mesiac</span>
              </div>
              <ul className="space-y-2 mb-8">
                <li className="flex items-center">
                  <span className="text-green-500 mr-2">✓</span>
                  Neobmedzený počet obyvateľov
                </li>
                <li className="flex items-center">
                  <span className="text-green-500 mr-2">✓</span>
                  Všetky funkcie
                </li>
                <li className="flex items-center">
                  <span className="text-green-500 mr-2">✓</span>
                  ISOH reporty
                </li>
                <li className="flex items-center">
                  <span className="text-green-500 mr-2">✓</span>
                  30 dní zadarmo
                </li>
              </ul>
              <Link
                href="/auth/register"
                className="block w-full text-center bg-green-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-700 transition"
              >
                Začať
              </Link>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-lg border-2 border-gray-200">
              <h3 className="text-2xl font-bold mb-2">Veľká obec</h3>
              <p className="text-gray-600 mb-4">Nad 5000 obyvateľov</p>
              <div className="text-4xl font-bold mb-6">
                {SUBSCRIPTION_PRICES.velka} €<span className="text-lg text-gray-600">/mesiac</span>
              </div>
              <ul className="space-y-2 mb-8">
                <li className="flex items-center">
                  <span className="text-green-500 mr-2">✓</span>
                  Neobmedzený počet obyvateľov
                </li>
                <li className="flex items-center">
                  <span className="text-green-500 mr-2">✓</span>
                  Všetky funkcie
                </li>
                <li className="flex items-center">
                  <span className="text-green-500 mr-2">✓</span>
                  ISOH reporty
                </li>
                <li className="flex items-center">
                  <span className="text-green-500 mr-2">✓</span>
                  30 dní zadarmo
                </li>
              </ul>
              <Link
                href="/auth/register"
                className="block w-full text-center bg-gray-200 text-gray-800 px-6 py-3 rounded-lg font-semibold hover:bg-gray-300 transition"
              >
                Začať
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-green-600 text-white py-16">
        <div className="max-w-4xl mx-auto text-center px-4">
          <h2 className="text-3xl font-bold mb-4">
            Pripravení začať?
          </h2>
          <p className="text-xl mb-8 text-green-100">
            Vyskúšajte náš systém 30 dní úplne zadarmo, bez kreditnej karty
          </p>
          <Link
            href="/auth/register"
            className="inline-block bg-white text-green-600 px-8 py-3 rounded-lg font-semibold hover:bg-green-50 transition"
          >
            Registrovať obec
          </Link>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p>&copy; 2026 Obecný odpadový systém. Všetky práva vyhradené.</p>
          <p className="mt-2 text-gray-400 text-sm">
            Vytvorené pre slovenské obce 🇸🇰
          </p>
        </div>
      </footer>
    </div>
  );
}
