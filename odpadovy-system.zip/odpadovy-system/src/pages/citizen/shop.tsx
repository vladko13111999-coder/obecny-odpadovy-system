import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import CitizenLayout from '@/components/citizen/CitizenLayout';
import { createBrowserSupabaseClient } from '@/lib/supabase';
import { Odmena, Obyvatel } from '@/types/database';
import { formatPoints } from '@/lib/utils';

export default function ShopPage() {
  const router = useRouter();
  const [odmeny, setOdmeny] = useState<Odmena[]>([]);
  const [currentUser, setCurrentUser] = useState<Obyvatel | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadShop();
  }, []);

  const loadShop = async () => {
    try {
      const supabase = createBrowserSupabaseClient();
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push('/auth/login');
        return;
      }

      // Get current user
      const { data: obyvatelData } = await supabase
        .from('obyvatelia')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (!obyvatelData) {
        router.push('/auth/login');
        return;
      }

      setCurrentUser(obyvatelData);

      // Get active rewards
      const { data: odmenyData } = await supabase
        .from('odmeny')
        .select('*')
        .eq('obec_id', obyvatelData.obec_id)
        .eq('stav', 'aktivna')
        .order('cena_v_bodoch', { ascending: true });

      setOdmeny(odmenyData || []);
    } catch (err) {
      console.error('Error loading shop:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleClaim = (odmena: Odmena) => {
    if (!currentUser) return;

    if (currentUser.celkove_body < odmena.cena_v_bodoch) {
      alert('Nemáte dostatok bodov na túto odmenu');
      return;
    }

    alert(
      `Gratulujeme! Získali ste odmenu: ${odmena.nazov}\n\n` +
      `Kontaktujte starostu obce pre vyzdvihnutie odmeny.\n` +
      `Táto funkcia bude v budúcnosti automatizovaná.`
    );
  };

  if (loading) {
    return (
      <CitizenLayout>
        <div className="text-center py-12">Načítavam...</div>
      </CitizenLayout>
    );
  }

  return (
    <CitizenLayout>
      <div>
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Obchodík s odmenami</h2>
          {currentUser && (
            <div className="bg-white px-6 py-3 rounded-lg shadow">
              <p className="text-sm text-gray-600">Vaše body</p>
              <p className="text-2xl font-bold text-green-600">
                {formatPoints(currentUser.celkove_body)}
              </p>
            </div>
          )}
        </div>

        {odmeny.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {odmeny.map((odmena) => {
              const canAfford = currentUser && currentUser.celkove_body >= odmena.cena_v_bodoch;

              return (
                <div
                  key={odmena.id}
                  className={`bg-white rounded-lg shadow overflow-hidden ${
                    !canAfford ? 'opacity-60' : ''
                  }`}
                >
                  {odmena.obrazok_url && (
                    <div className="h-48 bg-gray-200 flex items-center justify-center">
                      <img
                        src={odmena.obrazok_url}
                        alt={odmena.nazov}
                        className="h-full w-full object-cover"
                      />
                    </div>
                  )}
                  {!odmena.obrazok_url && (
                    <div className="h-48 bg-gradient-to-br from-green-400 to-blue-500 flex items-center justify-center">
                      <span className="text-6xl">🎁</span>
                    </div>
                  )}
                  
                  <div className="p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      {odmena.nazov}
                    </h3>
                    
                    {odmena.popis && (
                      <p className="text-sm text-gray-600 mb-4">{odmena.popis}</p>
                    )}
                    
                    <div className="mb-4">
                      <span className="text-2xl font-bold text-green-600">
                        {formatPoints(odmena.cena_v_bodoch)}
                      </span>
                    </div>
                    
                    {canAfford ? (
                      <button
                        onClick={() => handleClaim(odmena)}
                        className="w-full bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition font-semibold"
                      >
                        Získať odmenu
                      </button>
                    ) : (
                      <div className="w-full bg-gray-200 text-gray-500 px-4 py-2 rounded-lg text-center font-semibold">
                        Nedostatok bodov
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow p-12 text-center">
            <div className="text-6xl mb-4">🎁</div>
            <p className="text-gray-500 mb-2">Zatiaľ žiadne odmeny</p>
            <p className="text-sm text-gray-400">
              Starosta obce zatiaľ nepridala žiadne odmeny
            </p>
          </div>
        )}

        {/* Info Box */}
        <div className="mt-8 bg-green-50 border border-green-200 rounded-lg p-6">
          <h3 className="text-lg font-semibold mb-2 text-green-900">Ako fungujú odmeny?</h3>
          <ul className="space-y-2 text-sm text-green-800">
            <li>• Zbierajte body triedením odpadu</li>
            <li>• Vymieňajte body za odmeny v obchodíku</li>
            <li>• Odmeny vytvorené starostom môžu zahŕňať zľavy, darčeky a iné výhody</li>
            <li>• Po získaní odmeny kontaktujte starostu pre jej vyzdvihnutie</li>
          </ul>
        </div>
      </div>
    </CitizenLayout>
  );
}
