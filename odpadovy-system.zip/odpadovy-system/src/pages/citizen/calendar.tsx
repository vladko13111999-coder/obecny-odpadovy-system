import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import CitizenLayout from '@/components/citizen/CitizenLayout';
import { createBrowserSupabaseClient } from '@/lib/supabase';
import { Harmonogram } from '@/types/database';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';
import { formatDateForInput, getWasteTypeLabel, getWasteTypeColor } from '@/lib/utils';

export default function CitizenCalendarPage() {
  const router = useRouter();
  const [harmonogram, setHarmonogram] = useState<Harmonogram[]>([]);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadHarmonogram();
  }, []);

  const loadHarmonogram = async () => {
    try {
      const supabase = createBrowserSupabaseClient();
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push('/auth/login');
        return;
      }

      // Get current user
      const { data: obyvatelData } = await supabase
        .from('obyvatelia')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (!obyvatelData) {
        router.push('/auth/login');
        return;
      }

      // Get harmonogram
      const { data: harmonogramData } = await supabase
        .from('harmonogram')
        .select('*')
        .eq('obec_id', obyvatelData.obec_id)
        .order('datum', { ascending: true });

      setHarmonogram(harmonogramData || []);
    } catch (err) {
      console.error('Error loading harmonogram:', err);
    } finally {
      setLoading(false);
    }
  };

  const tileContent = ({ date, view }: { date: Date; view: string }) => {
    if (view === 'month') {
      const dateStr = formatDateForInput(date);
      const events = harmonogram.filter(h => h.datum === dateStr);
      
      if (events.length > 0) {
        return (
          <div className="flex flex-col gap-1 mt-1">
            {events.map((event) => (
              <div
                key={event.id}
                className={`text-xs px-1 rounded ${getWasteTypeColor(event.typ_odpadu)} text-white truncate`}
              >
                {getWasteTypeLabel(event.typ_odpadu)}
              </div>
            ))}
          </div>
        );
      }
    }
    return null;
  };

  const getEventsForDate = (date: Date) => {
    const dateStr = formatDateForInput(date);
    return harmonogram.filter(h => h.datum === dateStr);
  };

  const selectedEvents = getEventsForDate(selectedDate);

  const upcomingEvents = harmonogram
    .filter(h => new Date(h.datum) >= new Date())
    .slice(0, 5);

  if (loading) {
    return (
      <CitizenLayout>
        <div className="text-center py-12">Načítavam...</div>
      </CitizenLayout>
    );
  }

  return (
    <CitizenLayout>
      <div>
        <h2 className="text-2xl font-bold mb-6">Kalendár vývozov</h2>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Calendar */}
          <div className="lg:col-span-2 bg-white rounded-lg shadow p-6">
            <Calendar
              onChange={(value) => {
                if (value instanceof Date) {
                  setSelectedDate(value);
                }
              }}
              value={selectedDate}
              tileContent={tileContent}
              className="w-full border-none"
              locale="sk-SK"
            />
          </div>

          {/* Events for Selected Date */}
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold mb-4">
              {selectedDate.toLocaleDateString('sk-SK', { 
                day: 'numeric',
                month: 'long',
                year: 'numeric'
              })}
            </h3>

            {selectedEvents.length > 0 ? (
              <div className="space-y-3">
                {selectedEvents.map((event) => (
                  <div
                    key={event.id}
                    className="border rounded-lg p-3"
                  >
                    <span className={`px-2 py-1 text-xs rounded ${getWasteTypeColor(event.typ_odpadu)} text-white inline-block mb-2`}>
                      {getWasteTypeLabel(event.typ_odpadu)}
                    </span>
                    {event.poznamka && (
                      <p className="text-sm text-gray-600">{event.poznamka}</p>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500 text-sm text-center py-8">
                Žiadne vývozy naplánované
              </p>
            )}
          </div>
        </div>

        {/* Upcoming Collections */}
        <div className="mt-8 bg-white rounded-lg shadow">
          <div className="p-6 border-b">
            <h3 className="text-lg font-semibold">Nadchádzajúce vývozy</h3>
          </div>
          
          {upcomingEvents.length > 0 ? (
            <div className="divide-y">
              {upcomingEvents.map((event) => (
                <div key={event.id} className="p-6 flex items-center justify-between hover:bg-gray-50">
                  <div>
                    <p className="font-medium text-gray-900">
                      {new Date(event.datum).toLocaleDateString('sk-SK', {
                        weekday: 'long',
                        day: 'numeric',
                        month: 'long',
                        year: 'numeric',
                      })}
                    </p>
                    {event.poznamka && (
                      <p className="text-sm text-gray-500 mt-1">{event.poznamka}</p>
                    )}
                  </div>
                  <span className={`px-3 py-1 text-sm rounded ${getWasteTypeColor(event.typ_odpadu)} text-white`}>
                    {getWasteTypeLabel(event.typ_odpadu)}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-center py-12 text-gray-500">Žiadne nadchádzajúce vývozy</p>
          )}
        </div>

        {/* Info Box */}
        <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-6">
          <h3 className="text-lg font-semibold mb-2 text-blue-900">Pripomenutie</h3>
          <p className="text-sm text-blue-800">
            Sledujte kalendár vývozov a pripravte si odpad vopred. 
            Za triedený odpad (plast, papier, sklo) získate body, ktoré môžete vymeniť za odmeny!
          </p>
        </div>
      </div>

      <style jsx global>{`
        .react-calendar {
          width: 100%;
          border: none;
          font-family: inherit;
        }
        .react-calendar__tile {
          padding: 1em 0.5em;
          height: 80px;
        }
        .react-calendar__tile--active {
          background: #3b82f6 !important;
          color: white;
        }
        .react-calendar__tile--now {
          background: #dbeafe;
        }
        .react-calendar__month-view__days__day--weekend {
          color: #dc2626;
        }
      `}</style>
    </CitizenLayout>
  );
}
