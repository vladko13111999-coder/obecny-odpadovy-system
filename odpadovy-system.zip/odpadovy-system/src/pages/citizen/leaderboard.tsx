import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import CitizenLayout from '@/components/citizen/CitizenLayout';
import { createBrowserSupabaseClient } from '@/lib/supabase';
import { Obyvatel } from '@/types/database';
import { formatPoints } from '@/lib/utils';

export default function LeaderboardPage() {
  const router = useRouter();
  const [leaderboard, setLeaderboard] = useState<Obyvatel[]>([]);
  const [currentUser, setCurrentUser] = useState<Obyvatel | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadLeaderboard();
  }, []);

  const loadLeaderboard = async () => {
    try {
      const supabase = createBrowserSupabaseClient();
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push('/auth/login');
        return;
      }

      // Get current user
      const { data: obyvatelData } = await supabase
        .from('obyvatelia')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (!obyvatelData) {
        router.push('/auth/login');
        return;
      }

      setCurrentUser(obyvatelData);

      // Get leaderboard
      const { data: leaderboardData } = await supabase
        .from('obyvatelia')
        .select('*')
        .eq('obec_id', obyvatelData.obec_id)
        .order('celkove_body', { ascending: false })
        .limit(50);

      setLeaderboard(leaderboardData || []);
    } catch (err) {
      console.error('Error loading leaderboard:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <CitizenLayout>
        <div className="text-center py-12">Načítavam...</div>
      </CitizenLayout>
    );
  }

  const getMedalEmoji = (position: number) => {
    if (position === 1) return '🥇';
    if (position === 2) return '🥈';
    if (position === 3) return '🥉';
    return null;
  };

  return (
    <CitizenLayout>
      <div>
        <h2 className="text-2xl font-bold mb-6">Rebríček obyvateľov</h2>

        <div className="bg-white rounded-lg shadow overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Poradie</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Meno</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Adresa</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Body</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {leaderboard.map((obyvatel, index) => {
                const position = index + 1;
                const isCurrentUser = currentUser?.id === obyvatel.id;
                const medal = getMedalEmoji(position);

                return (
                  <tr
                    key={obyvatel.id}
                    className={`${isCurrentUser ? 'bg-blue-50 font-semibold' : 'hover:bg-gray-50'}`}
                  >
                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                      <div className="flex items-center gap-2">
                        {medal && <span className="text-2xl">{medal}</span>}
                        <span className={`${position <= 3 ? 'font-bold text-lg' : ''}`}>
                          #{position}
                        </span>
                        {isCurrentUser && (
                          <span className="ml-2 text-xs bg-blue-500 text-white px-2 py-1 rounded">
                            Vy
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {obyvatel.meno} {obyvatel.priezvisko}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {obyvatel.ulica && obyvatel.cislo_popisne
                        ? `${obyvatel.ulica} ${obyvatel.cislo_popisne}`
                        : '-'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`text-sm font-bold ${position <= 3 ? 'text-green-600 text-lg' : 'text-green-600'}`}>
                        {formatPoints(obyvatel.celkove_body)}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Info Box */}
        <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-6">
          <h3 className="text-lg font-semibold mb-2 text-blue-900">Ako získať viac bodov?</h3>
          <ul className="space-y-2 text-sm text-blue-800">
            <li>• Trieďte odpad pravidelne</li>
            <li>• Za každý kg plastu, papiera alebo skla získate 2 body</li>
            <li>• Čím viac triedite, tým vyššie sa dostanete v rebríčku</li>
            <li>• Body môžete minúť v obchodíku na odmeny</li>
          </ul>
        </div>
      </div>
    </CitizenLayout>
  );
}
