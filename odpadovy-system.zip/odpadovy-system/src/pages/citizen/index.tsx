import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import CitizenLayout from '@/components/citizen/CitizenLayout';
import { createBrowserSupabaseClient } from '@/lib/supabase';
import { formatPoints, formatWeight, getWasteTypeLabel, getWasteTypeColor } from '@/lib/utils';

export default function CitizenDashboardPage() {
  const router = useRouter();
  const [stats, setStats] = useState({
    celkove_body: 0,
    pocet_vyvozov: 0,
    celkove_mnozstvo: 0,
    poradie: 0,
  });
  const [recentCollections, setRecentCollections] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboard();
  }, []);

  const loadDashboard = async () => {
    try {
      const supabase = createBrowserSupabaseClient();
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push('/auth/login');
        return;
      }

      // Get obyvatel
      const { data: obyvatelData } = await supabase
        .from('obyvatelia')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (!obyvatelData) {
        router.push('/auth/login');
        return;
      }

      // Get collections
      const { data: vyvozyData } = await supabase
        .from('vyvozy')
        .select('*')
        .eq('obyvatel_id', obyvatelData.id)
        .order('datum', { ascending: false })
        .limit(5);

      const totalCollections = vyvozyData?.length || 0;
      const totalWeight = vyvozyData?.reduce((sum, v) => sum + Number(v.mnozstvo_kg), 0) || 0;

      // Get ranking
      const { data: allObyvatelia } = await supabase
        .from('obyvatelia')
        .select('celkove_body')
        .eq('obec_id', obyvatelData.obec_id)
        .order('celkove_body', { ascending: false });

      const ranking = (allObyvatelia?.findIndex(o => o.celkove_body <= obyvatelData.celkove_body) || 0) + 1;

      setStats({
        celkove_body: obyvatelData.celkove_body,
        pocet_vyvozov: totalCollections,
        celkove_mnozstvo: totalWeight,
        poradie: ranking,
      });

      setRecentCollections(vyvozyData || []);
    } catch (err) {
      console.error('Error loading dashboard:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <CitizenLayout>
        <div className="text-center py-12">Načítavam...</div>
      </CitizenLayout>
    );
  }

  return (
    <CitizenLayout>
      <div>
        <h2 className="text-2xl font-bold mb-6">Váš prehľad</h2>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Celkové body</p>
                <p className="text-3xl font-bold text-green-600">{stats.celkove_body}</p>
              </div>
              <div className="text-4xl">⭐</div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Počet vývozov</p>
                <p className="text-3xl font-bold text-gray-900">{stats.pocet_vyvozov}</p>
              </div>
              <div className="text-4xl">🗑️</div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Celkové množstvo</p>
                <p className="text-3xl font-bold text-gray-900">{stats.celkove_mnozstvo.toFixed(0)}</p>
                <p className="text-xs text-gray-500">kg</p>
              </div>
              <div className="text-4xl">📊</div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Vaše poradie</p>
                <p className="text-3xl font-bold text-blue-600">#{stats.poradie}</p>
              </div>
              <div className="text-4xl">🏆</div>
            </div>
          </div>
        </div>

        {/* Recent Collections */}
        <div className="bg-white rounded-lg shadow">
          <div className="p-6 border-b">
            <h3 className="text-lg font-semibold">Vaše posledné vývozy</h3>
          </div>
          
          {recentCollections.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Dátum</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Typ odpadu</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Množstvo</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Body</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {recentCollections.map((vyvoz) => {
                    const points = vyvoz.typ_odpadu === 'zmesovy' ? 0 : Number(vyvoz.mnozstvo_kg) * 2;
                    return (
                      <tr key={vyvoz.id}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {new Date(vyvoz.datum).toLocaleDateString('sk-SK')}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 py-1 text-xs rounded ${getWasteTypeColor(vyvoz.typ_odpadu)} text-white`}>
                            {getWasteTypeLabel(vyvoz.typ_odpadu)}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {formatWeight(vyvoz.mnozstvo_kg)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-green-600">
                          +{points}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-center py-12 text-gray-500">Zatiaľ žiadne vývozy</p>
          )}
        </div>

        {/* Motivation Section */}
        <div className="mt-8 bg-gradient-to-r from-green-500 to-blue-500 rounded-lg p-8 text-white">
          <h3 className="text-2xl font-bold mb-2">Skvelá práca! 🎉</h3>
          <p className="text-lg mb-4">
            Triedením odpadu pomáhate životnému prostrediu a získavate body na odmeny.
          </p>
          <div className="flex gap-4">
            <a
              href="/citizen/shop"
              className="bg-white text-green-600 px-6 py-2 rounded-lg font-semibold hover:bg-green-50 transition"
            >
              Pozrieť odmeny
            </a>
            <a
              href="/citizen/leaderboard"
              className="bg-green-600 text-white px-6 py-2 rounded-lg font-semibold hover:bg-green-700 transition"
            >
              Zobraziť rebríček
            </a>
          </div>
        </div>
      </div>
    </CitizenLayout>
  );
}
