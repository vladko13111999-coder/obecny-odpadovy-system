import type { NextApiRequest, NextApiResponse } from 'next';
import { createBrowserSupabaseClient } from '@/lib/supabase';
import { generateXMLReport, generateCSVReport, generateXLSXReport, filterCollectionsByQuarter } from '@/lib/reports';

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  try {
    const { kvartal, rok } = req.body;

    if (!kvartal || !rok) {
      return res.status(400).json({ message: 'Kvartál a rok sú povinné' });
    }

    const supabase = createBrowserSupabaseClient();

    // Get current user
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      return res.status(401).json({ message: 'Neautorizovaný prístup' });
    }

    // Get obec
    const { data: obecData, error: obecError } = await supabase
      .from('obce')
      .select('*')
      .eq('auth_user_id', user.id)
      .single();

    if (obecError || !obecData) {
      return res.status(404).json({ message: 'Obec nenájdená' });
    }

    // Get all collections for the municipality
    const { data: vyvozyData, error: vyvozyError } = await supabase
      .from('vyvozy')
      .select('*')
      .eq('obec_id', obecData.id);

    if (vyvozyError) {
      throw vyvozyError;
    }

    // Filter collections by quarter
    const quarterCollections = filterCollectionsByQuarter(vyvozyData || [], kvartal, rok);

    if (quarterCollections.length === 0) {
      return res.status(400).json({ message: 'Žiadne vývozy za vybraný kvartál' });
    }

    // Generate reports
    const xmlContent = await generateXMLReport(obecData, quarterCollections, kvartal, rok);
    const csvContent = await generateCSVReport(obecData, quarterCollections, kvartal, rok);
    const xlsxBuffer = await generateXLSXReport(obecData, quarterCollections, kvartal, rok);

    // Convert to base64 for storage
    const xlsxBase64 = xlsxBuffer.toString('base64');

    // Check if report already exists
    const { data: existingReport } = await supabase
      .from('reporty')
      .select('id')
      .eq('obec_id', obecData.id)
      .eq('kvartal', kvartal)
      .eq('rok', rok)
      .single();

    if (existingReport) {
      // Update existing report
      const { error: updateError } = await supabase
        .from('reporty')
        .update({
          subor_xml: xmlContent,
          subor_csv: csvContent,
          subor_xlsx: xlsxBase64,
          vygenerovane_dna: new Date().toISOString(),
        })
        .eq('id', existingReport.id);

      if (updateError) throw updateError;
    } else {
      // Create new report
      const { error: insertError } = await supabase
        .from('reporty')
        .insert({
          obec_id: obecData.id,
          kvartal,
          rok,
          subor_xml: xmlContent,
          subor_csv: csvContent,
          subor_xlsx: xlsxBase64,
        });

      if (insertError) throw insertError;
    }

    return res.status(200).json({ 
      message: 'Report úspešne vygenerovaný',
      kvartal,
      rok,
    });
  } catch (error: any) {
    console.error('Error generating report:', error);
    return res.status(500).json({ message: error.message || 'Chyba pri generovaní reportu' });
  }
}
