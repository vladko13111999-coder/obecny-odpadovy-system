import type { NextApiRequest, NextApiResponse } from 'next';
import { createBrowserSupabaseClient } from '@/lib/supabase';

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'GET') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  try {
    const { id, format } = req.query;

    if (!id || !format) {
      return res.status(400).json({ message: 'ID a formát sú povinné' });
    }

    if (!['xml', 'csv', 'xlsx'].includes(format as string)) {
      return res.status(400).json({ message: 'Neplatný formát' });
    }

    const supabase = createBrowserSupabaseClient();

    // Get current user
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      return res.status(401).json({ message: 'Neautorizovaný prístup' });
    }

    // Get obec
    const { data: obecData, error: obecError } = await supabase
      .from('obce')
      .select('id')
      .eq('auth_user_id', user.id)
      .single();

    if (obecError || !obecData) {
      return res.status(404).json({ message: 'Obec nenájdená' });
    }

    // Get report
    const { data: reportData, error: reportError } = await supabase
      .from('reporty')
      .select('*')
      .eq('id', id)
      .eq('obec_id', obecData.id)
      .single();

    if (reportError || !reportData) {
      return res.status(404).json({ message: 'Report nenájdený' });
    }

    let content: string | Buffer;
    let contentType: string;
    let filename: string;

    switch (format) {
      case 'xml':
        content = reportData.subor_xml;
        contentType = 'application/xml';
        filename = `report_Q${reportData.kvartal}_${reportData.rok}.xml`;
        break;
      case 'csv':
        content = reportData.subor_csv;
        contentType = 'text/csv';
        filename = `report_Q${reportData.kvartal}_${reportData.rok}.csv`;
        break;
      case 'xlsx':
        content = Buffer.from(reportData.subor_xlsx, 'base64');
        contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
        filename = `report_Q${reportData.kvartal}_${reportData.rok}.xlsx`;
        break;
      default:
        return res.status(400).json({ message: 'Neplatný formát' });
    }

    res.setHeader('Content-Type', contentType);
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(content);
  } catch (error: any) {
    console.error('Error downloading report:', error);
    return res.status(500).json({ message: error.message || 'Chyba pri sťahovaní reportu' });
  }
}
