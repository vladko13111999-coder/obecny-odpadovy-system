import type { NextApiRequest, NextApiResponse } from 'next';
import { buffer } from 'micro';
import { constructWebhookEvent } from '@/lib/stripe';
import { createServerSupabaseClient } from '@/lib/supabase';

// Disable body parsing for webhook
export const config = {
  api: {
    bodyParser: false,
  },
};

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  try {
    const buf = await buffer(req);
    const signature = req.headers['stripe-signature'] as string;

    if (!signature) {
      return res.status(400).json({ message: 'Missing stripe-signature header' });
    }

    // Construct and verify webhook event
    const event = constructWebhookEvent(buf, signature);

    const supabase = createServerSupabaseClient();

    // Handle different event types
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as any;
        
        // Get obec_id from metadata
        const obecId = session.metadata.obec_id;
        
        if (!obecId) {
          console.error('Missing obec_id in session metadata');
          return res.status(400).json({ message: 'Missing obec_id' });
        }

        // Update obec subscription status
        const { error } = await supabase
          .from('obce')
          .update({
            subscription_status: 'active',
            stripe_subscription_id: session.subscription,
          })
          .eq('id', obecId);

        if (error) {
          console.error('Error updating obec:', error);
          throw error;
        }

        console.log(`Subscription activated for obec ${obecId}`);
        break;
      }

      case 'customer.subscription.deleted': {
        const subscription = event.data.object as any;
        
        // Find obec by subscription ID
        const { data: obecData, error: findError } = await supabase
          .from('obce')
          .select('id')
          .eq('stripe_subscription_id', subscription.id)
          .single();

        if (findError || !obecData) {
          console.error('Obec not found for subscription:', subscription.id);
          return res.status(404).json({ message: 'Obec not found' });
        }

        // Update subscription status to cancelled
        const { error: updateError } = await supabase
          .from('obce')
          .update({ subscription_status: 'cancelled' })
          .eq('id', obecData.id);

        if (updateError) {
          console.error('Error updating obec:', updateError);
          throw updateError;
        }

        console.log(`Subscription cancelled for obec ${obecData.id}`);
        break;
      }

      case 'customer.subscription.updated': {
        const subscription = event.data.object as any;
        
        // Find obec by subscription ID
        const { data: obecData, error: findError } = await supabase
          .from('obce')
          .select('id')
          .eq('stripe_subscription_id', subscription.id)
          .single();

        if (findError || !obecData) {
          console.error('Obec not found for subscription:', subscription.id);
          return res.status(404).json({ message: 'Obec not found' });
        }

        // Update status based on subscription status
        let newStatus = 'active';
        if (subscription.status === 'canceled' || subscription.status === 'unpaid') {
          newStatus = 'cancelled';
        } else if (subscription.status === 'past_due') {
          newStatus = 'expired';
        }

        const { error: updateError } = await supabase
          .from('obce')
          .update({ subscription_status: newStatus })
          .eq('id', obecData.id);

        if (updateError) {
          console.error('Error updating obec:', updateError);
          throw updateError;
        }

        console.log(`Subscription updated for obec ${obecData.id}: ${newStatus}`);
        break;
      }

      default:
        console.log(`Unhandled event type: ${event.type}`);
    }

    return res.status(200).json({ received: true });
  } catch (error: any) {
    console.error('Webhook error:', error);
    return res.status(400).json({ message: error.message || 'Webhook error' });
  }
}
