import type { NextApiRequest, NextApiResponse } from 'next';
import { createBrowserSupabaseClient } from '@/lib/supabase';
import { createCheckoutSession, createStripeCustomer } from '@/lib/stripe';
import { VelkostObce } from '@/types/database';

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  try {
    const { velkost_obce } = req.body;

    if (!velkost_obce) {
      return res.status(400).json({ message: 'Veľkosť obce je povinná' });
    }

    const supabase = createBrowserSupabaseClient();

    // Get current user
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      return res.status(401).json({ message: 'Neautorizovaný prístup' });
    }

    // Get obec
    const { data: obecData, error: obecError } = await supabase
      .from('obce')
      .select('*')
      .eq('auth_user_id', user.id)
      .single();

    if (obecError || !obecData) {
      return res.status(404).json({ message: 'Obec nenájdená' });
    }

    // Create or get Stripe customer
    let customerId = obecData.stripe_customer_id;
    
    if (!customerId) {
      const customer = await createStripeCustomer(obecData.email, obecData.nazov);
      customerId = customer.id;

      // Update obec with customer ID
      await supabase
        .from('obce')
        .update({ stripe_customer_id: customerId })
        .eq('id', obecData.id);
    }

    // Create checkout session
    const session = await createCheckoutSession(
      obecData.id,
      velkost_obce as VelkostObce,
      obecData.email,
      customerId
    );

    return res.status(200).json({ url: session.url });
  } catch (error: any) {
    console.error('Error creating checkout session:', error);
    return res.status(500).json({ message: error.message || 'Chyba pri vytváraní platby' });
  }
}
