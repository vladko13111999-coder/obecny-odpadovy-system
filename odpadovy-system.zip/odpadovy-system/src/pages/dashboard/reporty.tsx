import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import { createBrowserSupabaseClient } from '@/lib/supabase';
import { Report } from '@/types/database';
import { getCurrentQuarter, getQuarterName } from '@/lib/utils';

export default function ReportyPage() {
  const router = useRouter();
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [selectedKvartal, setSelectedKvartal] = useState(getCurrentQuarter().kvartal);
  const [selectedRok, setSelectedRok] = useState(getCurrentQuarter().rok);

  useEffect(() => {
    loadReports();
  }, []);

  const loadReports = async () => {
    try {
      const supabase = createBrowserSupabaseClient();
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push('/auth/login');
        return;
      }

      const { data: obecData } = await supabase
        .from('obce')
        .select('id')
        .eq('auth_user_id', user.id)
        .single();

      if (!obecData) {
        router.push('/auth/login');
        return;
      }

      const { data, error } = await supabase
        .from('reporty')
        .select('*')
        .eq('obec_id', obecData.id)
        .order('rok', { ascending: false })
        .order('kvartal', { ascending: false });

      if (error) throw error;
      setReports(data || []);
    } catch (err) {
      console.error('Error loading reports:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateReport = async () => {
    setGenerating(true);
    
    try {
      const response = await fetch('/api/reports/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          kvartal: selectedKvartal,
          rok: selectedRok,
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Chyba pri generovaní reportu');
      }

      const data = await response.json();
      alert('Report bol úspešne vygenerovaný!');
      loadReports();
    } catch (err: any) {
      console.error('Error generating report:', err);
      alert('Chyba pri generovaní reportu: ' + err.message);
    } finally {
      setGenerating(false);
    }
  };

  const handleDownload = async (reportId: number, format: 'xml' | 'csv' | 'xlsx') => {
    try {
      const response = await fetch(`/api/reports/download?id=${reportId}&format=${format}`);
      
      if (!response.ok) {
        throw new Error('Chyba pri sťahovaní reportu');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      
      const report = reports.find(r => r.id === reportId);
      const filename = `report_Q${report?.kvartal}_${report?.rok}.${format}`;
      a.download = filename;
      
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (err: any) {
      console.error('Error downloading report:', err);
      alert('Chyba pri sťahovaní: ' + err.message);
    }
  };

  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 5 }, (_, i) => currentYear - i);

  return (
    <DashboardLayout>
      <div>
        <h1 className="text-3xl font-bold mb-8">Reporty pre ISOH</h1>

        {/* Generate New Report */}
        <div className="bg-white rounded-lg shadow p-6 mb-8">
          <h2 className="text-xl font-semibold mb-4">Vygenerovať nový report</h2>
          
          <div className="flex gap-4 items-end">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Kvartál
              </label>
              <select
                value={selectedKvartal}
                onChange={(e) => setSelectedKvartal(Number(e.target.value))}
                className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
              >
                <option value={1}>Q1 (Január - Marec)</option>
                <option value={2}>Q2 (Apríl - Jún)</option>
                <option value={3}>Q3 (Júl - September)</option>
                <option value={4}>Q4 (Október - December)</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Rok
              </label>
              <select
                value={selectedRok}
                onChange={(e) => setSelectedRok(Number(e.target.value))}
                className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
              >
                {years.map((year) => (
                  <option key={year} value={year}>{year}</option>
                ))}
              </select>
            </div>

            <button
              onClick={handleGenerateReport}
              disabled={generating}
              className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {generating ? 'Generujem...' : 'Vygenerovať report'}
            </button>
          </div>

          <div className="mt-4 bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm text-blue-800">
              <strong>Informácia:</strong> Report bude obsahovať všetky vývozy odpadu za vybraný kvartál.
              Vygenerujú sa 3 formáty: XML (pre ISOH), CSV a XLSX.
            </p>
          </div>
        </div>

        {/* Existing Reports */}
        <div className="bg-white rounded-lg shadow">
          <div className="p-6 border-b">
            <h2 className="text-xl font-semibold">Vygenerované reporty</h2>
          </div>
          
          {loading ? (
            <p className="text-center py-12">Načítavam...</p>
          ) : reports.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Obdobie</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Dátum vytvorenia</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Formáty</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {reports.map((report) => (
                    <tr key={report.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {getQuarterName(report.kvartal, report.rok)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {new Date(report.vygenerovane_dna).toLocaleDateString('sk-SK', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm space-x-2">
                        {report.subor_xml && (
                          <button
                            onClick={() => handleDownload(report.id, 'xml')}
                            className="text-blue-600 hover:text-blue-800 font-medium"
                          >
                            📄 XML
                          </button>
                        )}
                        {report.subor_csv && (
                          <button
                            onClick={() => handleDownload(report.id, 'csv')}
                            className="text-green-600 hover:text-green-800 font-medium"
                          >
                            📊 CSV
                          </button>
                        )}
                        {report.subor_xlsx && (
                          <button
                            onClick={() => handleDownload(report.id, 'xlsx')}
                            className="text-purple-600 hover:text-purple-800 font-medium"
                          >
                            📈 XLSX
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-center py-12 text-gray-500">Zatiaľ žiadne reporty</p>
          )}
        </div>

        {/* Info Section */}
        <div className="mt-8 bg-gray-50 rounded-lg p-6">
          <h3 className="text-lg font-semibold mb-4">Informácie o reportoch</h3>
          
          <div className="space-y-4">
            <div>
              <h4 className="font-medium text-gray-900 mb-2">XML formát (ISOH)</h4>
              <p className="text-sm text-gray-600">
                XML súbor je pripravený pre nahratie do systému ISOH podľa vyhlášky č. 366/2015 Z.z.
                Obsahuje identifikáciu obce, obdobie a údaje o nakladaní s odpadom.
              </p>
            </div>

            <div>
              <h4 className="font-medium text-gray-900 mb-2">Katalógové čísla odpadu</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Plast: <code className="bg-gray-200 px-2 py-1 rounded">20 01 39</code></li>
                <li>• Papier: <code className="bg-gray-200 px-2 py-1 rounded">20 01 01</code></li>
                <li>• Sklo: <code className="bg-gray-200 px-2 py-1 rounded">20 01 02</code></li>
                <li>• Zmesový odpad: <code className="bg-gray-200 px-2 py-1 rounded">20 03 01</code></li>
              </ul>
            </div>

            <div>
              <h4 className="font-medium text-gray-900 mb-2">Kód nakladania</h4>
              <p className="text-sm text-gray-600">
                Štandardne sa používa kód <code className="bg-gray-200 px-2 py-1 rounded">OO</code> (odovzdanie obchodníkovi).
              </p>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
