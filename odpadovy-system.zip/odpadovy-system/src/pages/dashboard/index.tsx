import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import { createBrowserSupabaseClient } from '@/lib/supabase';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { formatNumber, formatWeight, getWasteTypeLabel, getWasteTypeColor } from '@/lib/utils';

export default function DashboardPage() {
  const router = useRouter();
  const [stats, setStats] = useState({
    obyvatelia: 0,
    vyvozy: 0,
    celkoveBody: 0,
    celkoveMnozstvo: 0,
  });
  const [wasteByType, setWasteByType] = useState<any[]>([]);
  const [recentCollections, setRecentCollections] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const supabase = createBrowserSupabaseClient();
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push('/auth/login');
        return;
      }

      // Get obec
      const { data: obecData } = await supabase
        .from('obce')
        .select('id')
        .eq('auth_user_id', user.id)
        .single();

      if (!obecData) {
        router.push('/auth/login');
        return;
      }

      const obecId = obecData.id;

      // Get statistics
      const [obyvateliaRes, vyvozyRes, bodyRes] = await Promise.all([
        supabase.from('obyvatelia').select('id', { count: 'exact', head: true }).eq('obec_id', obecId),
        supabase.from('vyvozy').select('id, mnozstvo_kg', { count: 'exact' }).eq('obec_id', obecId),
        supabase.from('obyvatelia').select('celkove_body').eq('obec_id', obecId),
      ]);

      const totalObyvatelia = obyvateliaRes.count || 0;
      const totalVyvozy = vyvozyRes.count || 0;
      const totalBody = bodyRes.data?.reduce((sum, o) => sum + o.celkove_body, 0) || 0;
      const totalMnozstvo = vyvozyRes.data?.reduce((sum, v) => sum + Number(v.mnozstvo_kg), 0) || 0;

      setStats({
        obyvatelia: totalObyvatelia,
        vyvozy: totalVyvozy,
        celkoveBody: totalBody,
        celkoveMnozstvo: totalMnozstvo,
      });

      // Get waste by type
      const { data: wasteData } = await supabase
        .from('vyvozy')
        .select('typ_odpadu, mnozstvo_kg')
        .eq('obec_id', obecId);

      if (wasteData) {
        const grouped = wasteData.reduce((acc: any, v: any) => {
          if (!acc[v.typ_odpadu]) {
            acc[v.typ_odpadu] = 0;
          }
          acc[v.typ_odpadu] += Number(v.mnozstvo_kg);
          return acc;
        }, {});

        const chartData = Object.entries(grouped).map(([typ, mnozstvo]) => ({
          typ: getWasteTypeLabel(typ),
          mnozstvo: Number(mnozstvo),
          fill: getWasteTypeColor(typ).replace('bg-', '#').replace('-500', ''),
        }));

        setWasteByType(chartData);
      }

      // Get recent collections
      const { data: recentData } = await supabase
        .from('vyvozy')
        .select('*, obyvatel:obyvatelia(meno, priezvisko)')
        .eq('obec_id', obecId)
        .order('datum', { ascending: false })
        .limit(5);

      setRecentCollections(recentData || []);

    } catch (err) {
      console.error('Error loading dashboard:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <DashboardLayout>
        <div className="text-center py-12">Načítavam...</div>
      </DashboardLayout>
    );
  }

  const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#6b7280'];

  return (
    <DashboardLayout>
      <div>
        <h1 className="text-3xl font-bold mb-8">Prehľad</h1>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Obyvatelia</p>
                <p className="text-3xl font-bold text-gray-900">{formatNumber(stats.obyvatelia)}</p>
              </div>
              <div className="text-4xl">👥</div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Vývozy</p>
                <p className="text-3xl font-bold text-gray-900">{formatNumber(stats.vyvozy)}</p>
              </div>
              <div className="text-4xl">🗑️</div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Celkové body</p>
                <p className="text-3xl font-bold text-gray-900">{formatNumber(stats.celkoveBody)}</p>
              </div>
              <div className="text-4xl">⭐</div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Celkové množstvo</p>
                <p className="text-3xl font-bold text-gray-900">{stats.celkoveMnozstvo.toFixed(0)}</p>
                <p className="text-xs text-gray-500">kg</p>
              </div>
              <div className="text-4xl">📊</div>
            </div>
          </div>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Bar Chart */}
          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-lg font-semibold mb-4">Odpad podľa typu</h2>
            {wasteByType.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={wasteByType}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="typ" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="mnozstvo" fill="#10b981" name="Množstvo (kg)" />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <p className="text-gray-500 text-center py-12">Zatiaľ žiadne dáta</p>
            )}
          </div>

          {/* Pie Chart */}
          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-lg font-semibold mb-4">Rozdelenie odpadu</h2>
            {wasteByType.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={wasteByType}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={(entry) => `${entry.typ}: ${entry.mnozstvo.toFixed(0)} kg`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="mnozstvo"
                  >
                    {wasteByType.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <p className="text-gray-500 text-center py-12">Zatiaľ žiadne dáta</p>
            )}
          </div>
        </div>

        {/* Recent Collections */}
        <div className="bg-white rounded-lg shadow">
          <div className="p-6 border-b">
            <h2 className="text-lg font-semibold">Posledné vývozy</h2>
          </div>
          <div className="overflow-x-auto">
            {recentCollections.length > 0 ? (
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Dátum</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Obyvateľ</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Typ odpadu</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Množstvo</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {recentCollections.map((vyvoz) => (
                    <tr key={vyvoz.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {new Date(vyvoz.datum).toLocaleDateString('sk-SK')}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {vyvoz.obyvatel?.meno} {vyvoz.obyvatel?.priezvisko}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 text-xs rounded ${getWasteTypeColor(vyvoz.typ_odpadu)} text-white`}>
                          {getWasteTypeLabel(vyvoz.typ_odpadu)}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {formatWeight(vyvoz.mnozstvo_kg)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <p className="text-gray-500 text-center py-12">Zatiaľ žiadne vývozy</p>
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
