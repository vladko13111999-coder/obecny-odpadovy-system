import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import { createBrowserSupabaseClient } from '@/lib/supabase';
import { Obec } from '@/types/database';
import { SUBSCRIPTION_PRICES } from '@/types/database';
import { getSubscriptionStatusLabel, getSubscriptionStatusColor, daysUntil, formatPSC } from '@/lib/utils';

export default function NastaveniaPage() {
  const router = useRouter();
  const [obec, setObec] = useState<Obec | null>(null);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [formData, setFormData] = useState({
    nazov: '',
    email: '',
    ico: '',
    ulica: '',
    mesto: '',
    psc: '',
  });

  useEffect(() => {
    loadObec();
  }, []);

  const loadObec = async () => {
    try {
      const supabase = createBrowserSupabaseClient();
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push('/auth/login');
        return;
      }

      const { data, error } = await supabase
        .from('obce')
        .select('*')
        .eq('auth_user_id', user.id)
        .single();

      if (error || !data) {
        router.push('/auth/login');
        return;
      }

      setObec(data);
      setFormData({
        nazov: data.nazov,
        email: data.email,
        ico: data.ico || '',
        ulica: data.ulica || '',
        mesto: data.mesto || '',
        psc: data.psc || '',
      });
    } catch (err) {
      console.error('Error loading obec:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setProcessing(true);

    try {
      const supabase = createBrowserSupabaseClient();
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { error } = await supabase
        .from('obce')
        .update({
          nazov: formData.nazov,
          ico: formData.ico || null,
          ulica: formData.ulica || null,
          mesto: formData.mesto || null,
          psc: formData.psc || null,
        })
        .eq('auth_user_id', user.id);

      if (error) throw error;

      alert('Profil bol úspešne aktualizovaný');
      loadObec();
    } catch (err: any) {
      console.error('Error updating profile:', err);
      alert('Chyba pri aktualizácii: ' + err.message);
    } finally {
      setProcessing(false);
    }
  };

  const handleActivateSubscription = async () => {
    if (!obec) return;
    setProcessing(true);

    try {
      const response = await fetch('/api/stripe/create-checkout-session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          velkost_obce: obec.velkost_obce,
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Chyba pri vytváraní platby');
      }

      const { url } = await response.json();
      window.location.href = url;
    } catch (err: any) {
      console.error('Error creating checkout session:', err);
      alert('Chyba pri vytváraní platby: ' + err.message);
      setProcessing(false);
    }
  };

  if (loading || !obec) {
    return (
      <DashboardLayout>
        <div className="text-center py-12">Načítavam...</div>
      </DashboardLayout>
    );
  }

  const trialDaysRemaining = obec.subscription_status === 'trial' ? daysUntil(obec.trial_end) : 0;
  const isTrialActive = obec.subscription_status === 'trial' && trialDaysRemaining > 0;
  const isSubscriptionActive = obec.subscription_status === 'active';
  const subscriptionPrice = SUBSCRIPTION_PRICES[obec.velkost_obce];

  return (
    <DashboardLayout>
      <div>
        <h1 className="text-3xl font-bold mb-8">Nastavenia</h1>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Subscription Status */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-semibold mb-4">Predplatné</h2>
            
            <div className="space-y-4">
              <div>
                <label className="text-sm text-gray-600">Stav predplatného</label>
                <div className="mt-1">
                  <span className={`inline-block px-3 py-1 rounded ${getSubscriptionStatusColor(obec.subscription_status)}`}>
                    {getSubscriptionStatusLabel(obec.subscription_status)}
                  </span>
                </div>
              </div>

              <div>
                <label className="text-sm text-gray-600">Veľkosť obce</label>
                <p className="text-lg font-medium capitalize">{obec.velkost_obce}</p>
              </div>

              <div>
                <label className="text-sm text-gray-600">Cena</label>
                <p className="text-2xl font-bold text-gray-900">
                  {subscriptionPrice} € <span className="text-sm text-gray-500">/ mesiac</span>
                </p>
              </div>

              {isTrialActive && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <p className="text-sm text-blue-800">
                    <strong>Skúšobné obdobie:</strong> Zostáva {trialDaysRemaining} {trialDaysRemaining === 1 ? 'deň' : trialDaysRemaining < 5 ? 'dni' : 'dní'}
                  </p>
                  <p className="text-xs text-blue-600 mt-1">
                    Končí: {new Date(obec.trial_end).toLocaleDateString('sk-SK')}
                  </p>
                </div>
              )}

              {isSubscriptionActive && obec.stripe_subscription_id && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <p className="text-sm text-green-800">
                    <strong>Aktívne predplatné</strong>
                  </p>
                  <p className="text-xs text-green-600 mt-1">
                    Ďakujeme za vašu podporu!
                  </p>
                </div>
              )}

              {!isSubscriptionActive && (
                <button
                  onClick={handleActivateSubscription}
                  disabled={processing}
                  className="w-full bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition disabled:opacity-50 disabled:cursor-not-allowed font-semibold"
                >
                  {processing ? 'Spracovávam...' : 'Aktivovať predplatné'}
                </button>
              )}

              {obec.subscription_status === 'expired' || obec.subscription_status === 'cancelled' && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <p className="text-sm text-red-800">
                    Vaše predplatné vypršalo. Aktivujte ho pre pokračovanie v používaní systému.
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Profile Settings */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-semibold mb-4">Profil obce</h2>
            
            <form onSubmit={handleUpdateProfile} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Názov obce *
                </label>
                <input
                  type="text"
                  required
                  value={formData.nazov}
                  onChange={(e) => setFormData({ ...formData, nazov: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email
                </label>
                <input
                  type="email"
                  value={formData.email}
                  disabled
                  className="w-full px-3 py-2 border rounded-lg bg-gray-50 text-gray-500"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Email nie je možné zmeniť
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  IČO
                </label>
                <input
                  type="text"
                  value={formData.ico}
                  onChange={(e) => setFormData({ ...formData, ico: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Ulica
                </label>
                <input
                  type="text"
                  value={formData.ulica}
                  onChange={(e) => setFormData({ ...formData, ulica: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Mesto
                </label>
                <input
                  type="text"
                  value={formData.mesto}
                  onChange={(e) => setFormData({ ...formData, mesto: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  PSČ
                </label>
                <input
                  type="text"
                  value={formData.psc}
                  onChange={(e) => setFormData({ ...formData, psc: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>

              <button
                type="submit"
                disabled={processing}
                className="w-full bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {processing ? 'Ukladám...' : 'Uložiť zmeny'}
              </button>
            </form>
          </div>
        </div>

        {/* Info Section */}
        <div className="mt-8 bg-gray-50 rounded-lg p-6">
          <h3 className="text-lg font-semibold mb-4">Informácie o platbách</h3>
          
          <div className="space-y-3 text-sm text-gray-700">
            <p>
              • Platby sú spracovávané bezpečne cez Stripe
            </p>
            <p>
              • Predplatné je mesačné a automaticky sa obnovuje
            </p>
            <p>
              • Môžete kedykoľvek zrušiť predplatné
            </p>
            <p>
              • Pri zrušení budete mať prístup do konca plateného obdobia
            </p>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
