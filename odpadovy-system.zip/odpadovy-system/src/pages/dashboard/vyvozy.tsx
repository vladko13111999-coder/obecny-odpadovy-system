import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import { createBrowserSupabaseClient } from '@/lib/supabase';
import { VyvozWithObyvatel, Obyvatel, VyvozForm, TypOdpadu } from '@/types/database';
import { formatWeight, formatDateForInput, getWasteTypeLabel, getWasteTypeColor, formatPoints } from '@/lib/utils';

export default function VyvozyPage() {
  const router = useRouter();
  const [vyvozy, setVyvozy] = useState<VyvozWithObyvatel[]>([]);
  const [obyvatelia, setObyvatelia] = useState<Obyvatel[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState<VyvozForm>({
    obyvatel_id: 0,
    datum: formatDateForInput(new Date()),
    typ_odpadu: 'plast',
    mnozstvo_kg: 0,
  });
  const [filterType, setFilterType] = useState<string>('all');
  const [filterMonth, setFilterMonth] = useState<string>('all');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const supabase = createBrowserSupabaseClient();
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push('/auth/login');
        return;
      }

      const { data: obecData } = await supabase
        .from('obce')
        .select('id')
        .eq('auth_user_id', user.id)
        .single();

      if (!obecData) {
        router.push('/auth/login');
        return;
      }

      // Load vyvozy
      const { data: vyvozyData, error: vyvozyError } = await supabase
        .from('vyvozy')
        .select('*, obyvatel:obyvatelia(id, meno, priezvisko, ulica, cislo_popisne)')
        .eq('obec_id', obecData.id)
        .order('datum', { ascending: false });

      if (vyvozyError) throw vyvozyError;
      setVyvozy(vyvozyData || []);

      // Load obyvatelia for dropdown
      const { data: obyvateliaData, error: obyvateliaError } = await supabase
        .from('obyvatelia')
        .select('*')
        .eq('obec_id', obecData.id)
        .order('priezvisko', { ascending: true });

      if (obyvateliaError) throw obyvateliaError;
      setObyvatelia(obyvateliaData || []);
      
      if (obyvateliaData && obyvateliaData.length > 0 && formData.obyvatel_id === 0) {
        setFormData({ ...formData, obyvatel_id: obyvateliaData[0].id });
      }
    } catch (err) {
      console.error('Error loading data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const supabase = createBrowserSupabaseClient();
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: obecData } = await supabase
        .from('obce')
        .select('id')
        .eq('auth_user_id', user.id)
        .single();

      if (!obecData) return;

      if (editingId) {
        // Update
        const { error } = await supabase
          .from('vyvozy')
          .update({
            obyvatel_id: formData.obyvatel_id,
            datum: formData.datum,
            typ_odpadu: formData.typ_odpadu,
            mnozstvo_kg: formData.mnozstvo_kg,
          })
          .eq('id', editingId);

        if (error) throw error;
      } else {
        // Create
        const { error } = await supabase
          .from('vyvozy')
          .insert({
            obec_id: obecData.id,
            obyvatel_id: formData.obyvatel_id,
            datum: formData.datum,
            typ_odpadu: formData.typ_odpadu,
            mnozstvo_kg: formData.mnozstvo_kg,
            kod_nakladania: 'OO',
          });

        if (error) throw error;
      }

      setShowModal(false);
      setEditingId(null);
      setFormData({
        obyvatel_id: obyvatelia[0]?.id || 0,
        datum: formatDateForInput(new Date()),
        typ_odpadu: 'plast',
        mnozstvo_kg: 0,
      });
      loadData();
    } catch (err: any) {
      console.error('Error saving vyvoz:', err);
      alert('Chyba pri ukladaní: ' + err.message);
    }
  };

  const handleEdit = (vyvoz: VyvozWithObyvatel) => {
    setEditingId(vyvoz.id);
    setFormData({
      obyvatel_id: vyvoz.obyvatel_id,
      datum: formatDateForInput(vyvoz.datum),
      typ_odpadu: vyvoz.typ_odpadu,
      mnozstvo_kg: Number(vyvoz.mnozstvo_kg),
    });
    setShowModal(true);
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Naozaj chcete odstrániť tento vývoz?')) return;

    try {
      const supabase = createBrowserSupabaseClient();
      const { error } = await supabase
        .from('vyvozy')
        .delete()
        .eq('id', id);

      if (error) throw error;
      loadData();
    } catch (err: any) {
      console.error('Error deleting vyvoz:', err);
      alert('Chyba pri mazaní: ' + err.message);
    }
  };

  const calculatePoints = (typ: TypOdpadu, mnozstvo: number) => {
    if (typ === 'zmesovy') return 0;
    return mnozstvo * 2;
  };

  const filteredVyvozy = vyvozy.filter((v) => {
    if (filterType !== 'all' && v.typ_odpadu !== filterType) return false;
    if (filterMonth !== 'all') {
      const vyvozMonth = new Date(v.datum).toISOString().slice(0, 7);
      if (vyvozMonth !== filterMonth) return false;
    }
    return true;
  });

  return (
    <DashboardLayout>
      <div>
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold">Vývozy odpadu</h1>
          <button
            onClick={() => {
              setEditingId(null);
              setFormData({
                obyvatel_id: obyvatelia[0]?.id || 0,
                datum: formatDateForInput(new Date()),
                typ_odpadu: 'plast',
                mnozstvo_kg: 0,
              });
              setShowModal(true);
            }}
            className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition"
            disabled={obyvatelia.length === 0}
          >
            + Pridať vývoz
          </button>
        </div>

        {obyvatelia.length === 0 && (
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
            <p className="text-yellow-800">
              Pred pridaním vývozu musíte najprv pridať obyvateľov.{' '}
              <a href="/dashboard/obyvatelia" className="underline font-semibold">
                Pridať obyvateľov
              </a>
            </p>
          </div>
        )}

        {/* Filters */}
        <div className="mb-6 flex gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Typ odpadu
            </label>
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
            >
              <option value="all">Všetky typy</option>
              <option value="plast">Plast</option>
              <option value="papier">Papier</option>
              <option value="sklo">Sklo</option>
              <option value="zmesovy">Zmesový</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Mesiac
            </label>
            <input
              type="month"
              value={filterMonth}
              onChange={(e) => setFilterMonth(e.target.value)}
              className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
            />
          </div>

          {(filterType !== 'all' || filterMonth !== 'all') && (
            <div className="flex items-end">
              <button
                onClick={() => {
                  setFilterType('all');
                  setFilterMonth('all');
                }}
                className="px-4 py-2 text-sm text-gray-600 hover:text-gray-800"
              >
                Zrušiť filtre
              </button>
            </div>
          )}
        </div>

        {/* Table */}
        <div className="bg-white rounded-lg shadow overflow-hidden">
          {loading ? (
            <p className="text-center py-12">Načítavam...</p>
          ) : filteredVyvozy.length > 0 ? (
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Dátum</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Obyvateľ</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Typ odpadu</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Množstvo</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Body</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Akcie</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredVyvozy.map((vyvoz) => (
                  <tr key={vyvoz.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {new Date(vyvoz.datum).toLocaleDateString('sk-SK')}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {vyvoz.obyvatel?.meno} {vyvoz.obyvatel?.priezvisko}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 text-xs rounded ${getWasteTypeColor(vyvoz.typ_odpadu)} text-white`}>
                        {getWasteTypeLabel(vyvoz.typ_odpadu)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {formatWeight(vyvoz.mnozstvo_kg)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-green-600">
                      +{calculatePoints(vyvoz.typ_odpadu, Number(vyvoz.mnozstvo_kg))}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm space-x-2">
                      <button
                        onClick={() => handleEdit(vyvoz)}
                        className="text-blue-600 hover:text-blue-800"
                      >
                        Upraviť
                      </button>
                      <button
                        onClick={() => handleDelete(vyvoz.id)}
                        className="text-red-600 hover:text-red-800"
                      >
                        Zmazať
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <p className="text-center py-12 text-gray-500">
              {vyvozy.length === 0 ? 'Zatiaľ žiadne vývozy' : 'Nenašli sa žiadne vývozy'}
            </p>
          )}
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-8 max-w-md w-full mx-4">
            <h2 className="text-2xl font-bold mb-6">
              {editingId ? 'Upraviť vývoz' : 'Pridať vývoz'}
            </h2>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Obyvateľ *
                </label>
                <select
                  required
                  value={formData.obyvatel_id}
                  onChange={(e) => setFormData({ ...formData, obyvatel_id: Number(e.target.value) })}
                  className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                >
                  {obyvatelia.map((o) => (
                    <option key={o.id} value={o.id}>
                      {o.meno} {o.priezvisko} {o.ulica && `(${o.ulica} ${o.cislo_popisne})`}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Dátum *
                </label>
                <input
                  type="date"
                  required
                  value={formData.datum}
                  onChange={(e) => setFormData({ ...formData, datum: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Typ odpadu *
                </label>
                <select
                  required
                  value={formData.typ_odpadu}
                  onChange={(e) => setFormData({ ...formData, typ_odpadu: e.target.value as TypOdpadu })}
                  className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                >
                  <option value="plast">Plast (2 body/kg)</option>
                  <option value="papier">Papier (2 body/kg)</option>
                  <option value="sklo">Sklo (2 body/kg)</option>
                  <option value="zmesovy">Zmesový (0 bodov/kg)</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Množstvo (kg) *
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  required
                  value={formData.mnozstvo_kg}
                  onChange={(e) => setFormData({ ...formData, mnozstvo_kg: Number(e.target.value) })}
                  className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>

              {formData.mnozstvo_kg > 0 && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                  <p className="text-sm text-green-800">
                    <strong>Body:</strong> +{calculatePoints(formData.typ_odpadu, formData.mnozstvo_kg)}
                  </p>
                </div>
              )}

              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition"
                >
                  {editingId ? 'Uložiť' : 'Pridať'}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowModal(false);
                    setEditingId(null);
                  }}
                  className="flex-1 bg-gray-200 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-300 transition"
                >
                  Zrušiť
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}
