import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import { createBrowserSupabaseClient } from '@/lib/supabase';
import { Odmena, OdmenaForm, StavOdmeny } from '@/types/database';
import { formatPoints } from '@/lib/utils';

export default function OdmenyPage() {
  const router = useRouter();
  const [odmeny, setOdmeny] = useState<Odmena[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState<OdmenaForm>({
    nazov: '',
    popis: '',
    cena_v_bodoch: 0,
    obrazok_url: '',
    stav: 'aktivna',
  });

  useEffect(() => {
    loadOdmeny();
  }, []);

  const loadOdmeny = async () => {
    try {
      const supabase = createBrowserSupabaseClient();
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push('/auth/login');
        return;
      }

      const { data: obecData } = await supabase
        .from('obce')
        .select('id')
        .eq('auth_user_id', user.id)
        .single();

      if (!obecData) {
        router.push('/auth/login');
        return;
      }

      const { data, error } = await supabase
        .from('odmeny')
        .select('*')
        .eq('obec_id', obecData.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setOdmeny(data || []);
    } catch (err) {
      console.error('Error loading odmeny:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const supabase = createBrowserSupabaseClient();
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: obecData } = await supabase
        .from('obce')
        .select('id')
        .eq('auth_user_id', user.id)
        .single();

      if (!obecData) return;

      if (editingId) {
        // Update
        const { error } = await supabase
          .from('odmeny')
          .update({
            ...formData,
            updated_at: new Date().toISOString(),
          })
          .eq('id', editingId);

        if (error) throw error;
      } else {
        // Create
        const { error } = await supabase
          .from('odmeny')
          .insert({
            ...formData,
            obec_id: obecData.id,
          });

        if (error) throw error;
      }

      setShowModal(false);
      setEditingId(null);
      setFormData({ nazov: '', popis: '', cena_v_bodoch: 0, obrazok_url: '', stav: 'aktivna' });
      loadOdmeny();
    } catch (err: any) {
      console.error('Error saving odmena:', err);
      alert('Chyba pri ukladaní: ' + err.message);
    }
  };

  const handleEdit = (odmena: Odmena) => {
    setEditingId(odmena.id);
    setFormData({
      nazov: odmena.nazov,
      popis: odmena.popis || '',
      cena_v_bodoch: odmena.cena_v_bodoch,
      obrazok_url: odmena.obrazok_url || '',
      stav: odmena.stav,
    });
    setShowModal(true);
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Naozaj chcete odstrániť túto odmenu?')) return;

    try {
      const supabase = createBrowserSupabaseClient();
      const { error } = await supabase
        .from('odmeny')
        .delete()
        .eq('id', id);

      if (error) throw error;
      loadOdmeny();
    } catch (err: any) {
      console.error('Error deleting odmena:', err);
      alert('Chyba pri mazaní: ' + err.message);
    }
  };

  const handleToggleStatus = async (id: number, currentStatus: StavOdmeny) => {
    try {
      const supabase = createBrowserSupabaseClient();
      const newStatus: StavOdmeny = currentStatus === 'aktivna' ? 'neaktivna' : 'aktivna';
      
      const { error } = await supabase
        .from('odmeny')
        .update({ 
          stav: newStatus,
          updated_at: new Date().toISOString(),
        })
        .eq('id', id);

      if (error) throw error;
      loadOdmeny();
    } catch (err: any) {
      console.error('Error toggling status:', err);
      alert('Chyba pri zmene stavu: ' + err.message);
    }
  };

  return (
    <DashboardLayout>
      <div>
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold">Odmeny</h1>
          <button
            onClick={() => {
              setEditingId(null);
              setFormData({ nazov: '', popis: '', cena_v_bodoch: 0, obrazok_url: '', stav: 'aktivna' });
              setShowModal(true);
            }}
            className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition"
          >
            + Pridať odmenu
          </button>
        </div>

        {/* Grid of Rewards */}
        {loading ? (
          <p className="text-center py-12">Načítavam...</p>
        ) : odmeny.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {odmeny.map((odmena) => (
              <div
                key={odmena.id}
                className={`bg-white rounded-lg shadow overflow-hidden ${
                  odmena.stav === 'neaktivna' ? 'opacity-60' : ''
                }`}
              >
                {odmena.obrazok_url && (
                  <div className="h-48 bg-gray-200 flex items-center justify-center">
                    <img
                      src={odmena.obrazok_url}
                      alt={odmena.nazov}
                      className="h-full w-full object-cover"
                    />
                  </div>
                )}
                {!odmena.obrazok_url && (
                  <div className="h-48 bg-gradient-to-br from-green-400 to-blue-500 flex items-center justify-center">
                    <span className="text-6xl">🎁</span>
                  </div>
                )}
                
                <div className="p-6">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-lg font-semibold text-gray-900">{odmena.nazov}</h3>
                    <span className={`px-2 py-1 text-xs rounded ${
                      odmena.stav === 'aktivna' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-gray-100 text-gray-800'
                    }`}>
                      {odmena.stav === 'aktivna' ? 'Aktívna' : 'Neaktívna'}
                    </span>
                  </div>
                  
                  {odmena.popis && (
                    <p className="text-sm text-gray-600 mb-4">{odmena.popis}</p>
                  )}
                  
                  <div className="mb-4">
                    <span className="text-2xl font-bold text-green-600">
                      {formatPoints(odmena.cena_v_bodoch)}
                    </span>
                  </div>
                  
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleEdit(odmena)}
                      className="flex-1 px-3 py-2 text-sm bg-blue-50 text-blue-600 rounded hover:bg-blue-100 transition"
                    >
                      Upraviť
                    </button>
                    <button
                      onClick={() => handleToggleStatus(odmena.id, odmena.stav)}
                      className="flex-1 px-3 py-2 text-sm bg-gray-50 text-gray-600 rounded hover:bg-gray-100 transition"
                    >
                      {odmena.stav === 'aktivna' ? 'Deaktivovať' : 'Aktivovať'}
                    </button>
                    <button
                      onClick={() => handleDelete(odmena.id)}
                      className="px-3 py-2 text-sm bg-red-50 text-red-600 rounded hover:bg-red-100 transition"
                    >
                      Zmazať
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow p-12 text-center">
            <div className="text-6xl mb-4">🎁</div>
            <p className="text-gray-500 mb-4">Zatiaľ žiadne odmeny</p>
            <button
              onClick={() => setShowModal(true)}
              className="text-green-600 hover:text-green-700 font-semibold"
            >
              Pridať prvú odmenu
            </button>
          </div>
        )}

        {/* Info Box */}
        <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-4">
          <p className="text-sm text-blue-800">
            <strong>Tip:</strong> Odmeny slúžia na motiváciu obyvateľov k triedeniu odpadu. 
            Obyvatelia môžu minúť nazbierané body na odmeny v obchodíku. 
            Neaktívne odmeny sa nezobrazujú obyvateľom.
          </p>
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-8 max-w-md w-full mx-4 max-h-[90vh] overflow-y-auto">
            <h2 className="text-2xl font-bold mb-6">
              {editingId ? 'Upraviť odmenu' : 'Pridať odmenu'}
            </h2>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Názov *
                </label>
                <input
                  type="text"
                  required
                  value={formData.nazov}
                  onChange={(e) => setFormData({ ...formData, nazov: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                  placeholder="napr. Zľava 10% v miestnej kaviarni"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Popis
                </label>
                <textarea
                  value={formData.popis}
                  onChange={(e) => setFormData({ ...formData, popis: e.target.value })}
                  rows={3}
                  className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                  placeholder="Stručný popis odmeny..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Cena v bodoch *
                </label>
                <input
                  type="number"
                  min="0"
                  required
                  value={formData.cena_v_bodoch}
                  onChange={(e) => setFormData({ ...formData, cena_v_bodoch: Number(e.target.value) })}
                  className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  URL obrázka
                </label>
                <input
                  type="url"
                  value={formData.obrazok_url}
                  onChange={(e) => setFormData({ ...formData, obrazok_url: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                  placeholder="https://example.com/image.jpg"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Voliteľné - ak nevyplníte, zobrazí sa predvolený obrázok
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Stav *
                </label>
                <select
                  required
                  value={formData.stav}
                  onChange={(e) => setFormData({ ...formData, stav: e.target.value as StavOdmeny })}
                  className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                >
                  <option value="aktivna">Aktívna</option>
                  <option value="neaktivna">Neaktívna</option>
                </select>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition"
                >
                  {editingId ? 'Uložiť' : 'Pridať'}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowModal(false);
                    setEditingId(null);
                    setFormData({ nazov: '', popis: '', cena_v_bodoch: 0, obrazok_url: '', stav: 'aktivna' });
                  }}
                  className="flex-1 bg-gray-200 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-300 transition"
                >
                  Zrušiť
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}
