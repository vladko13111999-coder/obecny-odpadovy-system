import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import { createBrowserSupabaseClient } from '@/lib/supabase';
import { Obyvatel, ObyvatelForm } from '@/types/database';
import { formatPoints } from '@/lib/utils';

export default function ObyvateliaPage() {
  const router = useRouter();
  const [obyvatelia, setObyvatelia] = useState<Obyvatel[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState<ObyvatelForm>({
    meno: '',
    priezvisko: '',
    ulica: '',
    cislo_popisne: '',
  });
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    loadObyvatelia();
  }, []);

  const loadObyvatelia = async () => {
    try {
      const supabase = createBrowserSupabaseClient();
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push('/auth/login');
        return;
      }

      const { data: obecData } = await supabase
        .from('obce')
        .select('id')
        .eq('auth_user_id', user.id)
        .single();

      if (!obecData) {
        router.push('/auth/login');
        return;
      }

      const { data, error } = await supabase
        .from('obyvatelia')
        .select('*')
        .eq('obec_id', obecData.id)
        .order('priezvisko', { ascending: true });

      if (error) throw error;
      setObyvatelia(data || []);
    } catch (err) {
      console.error('Error loading obyvatelia:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const supabase = createBrowserSupabaseClient();
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: obecData } = await supabase
        .from('obce')
        .select('id')
        .eq('auth_user_id', user.id)
        .single();

      if (!obecData) return;

      if (editingId) {
        // Update
        const { error } = await supabase
          .from('obyvatelia')
          .update(formData)
          .eq('id', editingId);

        if (error) throw error;
      } else {
        // Create
        const { error } = await supabase
          .from('obyvatelia')
          .insert({
            ...formData,
            obec_id: obecData.id,
          });

        if (error) throw error;
      }

      setShowModal(false);
      setEditingId(null);
      setFormData({ meno: '', priezvisko: '', ulica: '', cislo_popisne: '' });
      loadObyvatelia();
    } catch (err: any) {
      console.error('Error saving obyvatel:', err);
      alert('Chyba pri ukladaní: ' + err.message);
    }
  };

  const handleEdit = (obyvatel: Obyvatel) => {
    setEditingId(obyvatel.id);
    setFormData({
      meno: obyvatel.meno,
      priezvisko: obyvatel.priezvisko,
      ulica: obyvatel.ulica || '',
      cislo_popisne: obyvatel.cislo_popisne || '',
    });
    setShowModal(true);
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Naozaj chcete odstrániť tohto obyvateľa?')) return;

    try {
      const supabase = createBrowserSupabaseClient();
      const { error } = await supabase
        .from('obyvatelia')
        .delete()
        .eq('id', id);

      if (error) throw error;
      loadObyvatelia();
    } catch (err: any) {
      console.error('Error deleting obyvatel:', err);
      alert('Chyba pri mazaní: ' + err.message);
    }
  };

  const filteredObyvatelia = obyvatelia.filter((o) =>
    `${o.meno} ${o.priezvisko} ${o.ulica || ''} ${o.cislo_popisne || ''}`
      .toLowerCase()
      .includes(searchTerm.toLowerCase())
  );

  return (
    <DashboardLayout>
      <div>
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold">Obyvatelia</h1>
          <button
            onClick={() => {
              setEditingId(null);
              setFormData({ meno: '', priezvisko: '', ulica: '', cislo_popisne: '' });
              setShowModal(true);
            }}
            className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition"
          >
            + Pridať obyvateľa
          </button>
        </div>

        {/* Search */}
        <div className="mb-6">
          <input
            type="text"
            placeholder="Hľadať obyvateľa..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full max-w-md px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
          />
        </div>

        {/* Table */}
        <div className="bg-white rounded-lg shadow overflow-hidden">
          {loading ? (
            <p className="text-center py-12">Načítavam...</p>
          ) : filteredObyvatelia.length > 0 ? (
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Meno</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Priezvisko</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Adresa</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Body</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Akcie</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredObyvatelia.map((obyvatel) => (
                  <tr key={obyvatel.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {obyvatel.id}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {obyvatel.meno}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {obyvatel.priezvisko}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {obyvatel.ulica && obyvatel.cislo_popisne
                        ? `${obyvatel.ulica} ${obyvatel.cislo_popisne}`
                        : '-'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      <span className="font-semibold text-green-600">
                        {formatPoints(obyvatel.celkove_body)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm space-x-2">
                      <button
                        onClick={() => handleEdit(obyvatel)}
                        className="text-blue-600 hover:text-blue-800"
                      >
                        Upraviť
                      </button>
                      <button
                        onClick={() => handleDelete(obyvatel.id)}
                        className="text-red-600 hover:text-red-800"
                      >
                        Zmazať
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <p className="text-center py-12 text-gray-500">
              {searchTerm ? 'Nenašli sa žiadni obyvatelia' : 'Zatiaľ žiadni obyvatelia'}
            </p>
          )}
        </div>

        {/* Info Box */}
        <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
          <p className="text-sm text-blue-800">
            <strong>Tip:</strong> ID obyvateľa slúži ako overovací kód pre registráciu občana. 
            Obyvateľ použije toto ID pri registrácii v sekcii "Registrácia občana".
          </p>
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-8 max-w-md w-full mx-4">
            <h2 className="text-2xl font-bold mb-6">
              {editingId ? 'Upraviť obyvateľa' : 'Pridať obyvateľa'}
            </h2>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Meno *
                </label>
                <input
                  type="text"
                  required
                  value={formData.meno}
                  onChange={(e) => setFormData({ ...formData, meno: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Priezvisko *
                </label>
                <input
                  type="text"
                  required
                  value={formData.priezvisko}
                  onChange={(e) => setFormData({ ...formData, priezvisko: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Ulica
                </label>
                <input
                  type="text"
                  value={formData.ulica}
                  onChange={(e) => setFormData({ ...formData, ulica: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Číslo popisné
                </label>
                <input
                  type="text"
                  value={formData.cislo_popisne}
                  onChange={(e) => setFormData({ ...formData, cislo_popisne: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition"
                >
                  {editingId ? 'Uložiť' : 'Pridať'}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowModal(false);
                    setEditingId(null);
                    setFormData({ meno: '', priezvisko: '', ulica: '', cislo_popisne: '' });
                  }}
                  className="flex-1 bg-gray-200 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-300 transition"
                >
                  Zrušiť
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}
