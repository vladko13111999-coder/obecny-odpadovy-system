import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import { createBrowserSupabaseClient } from '@/lib/supabase';
import { Harmonogram, HarmonogramForm } from '@/types/database';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';
import { formatDateForInput, getWasteTypeLabel, getWasteTypeColor } from '@/lib/utils';

type ValuePiece = Date | null;
type Value = ValuePiece | [ValuePiece, ValuePiece];

export default function HarmonogramPage() {
  const router = useRouter();
  const [harmonogram, setHarmonogram] = useState<Harmonogram[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [formData, setFormData] = useState<HarmonogramForm>({
    datum: formatDateForInput(new Date()),
    typ_odpadu: '',
    poznamka: '',
  });

  useEffect(() => {
    loadHarmonogram();
  }, []);

  const loadHarmonogram = async () => {
    try {
      const supabase = createBrowserSupabaseClient();
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push('/auth/login');
        return;
      }

      const { data: obecData } = await supabase
        .from('obce')
        .select('id')
        .eq('auth_user_id', user.id)
        .single();

      if (!obecData) {
        router.push('/auth/login');
        return;
      }

      const { data, error } = await supabase
        .from('harmonogram')
        .select('*')
        .eq('obec_id', obecData.id)
        .order('datum', { ascending: true });

      if (error) throw error;
      setHarmonogram(data || []);
    } catch (err) {
      console.error('Error loading harmonogram:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDateClick = (date: Date) => {
    setSelectedDate(date);
    setFormData({
      datum: formatDateForInput(date),
      typ_odpadu: '',
      poznamka: '',
    });
    setShowModal(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const supabase = createBrowserSupabaseClient();
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: obecData } = await supabase
        .from('obce')
        .select('id')
        .eq('auth_user_id', user.id)
        .single();

      if (!obecData) return;

      const { error } = await supabase
        .from('harmonogram')
        .insert({
          obec_id: obecData.id,
          datum: formData.datum,
          typ_odpadu: formData.typ_odpadu,
          poznamka: formData.poznamka || null,
        });

      if (error) {
        if (error.code === '23505') {
          alert('Pre tento dátum a typ odpadu už existuje záznam');
        } else {
          throw error;
        }
        return;
      }

      setShowModal(false);
      setFormData({ datum: '', typ_odpadu: '', poznamka: '' });
      loadHarmonogram();
    } catch (err: any) {
      console.error('Error saving harmonogram:', err);
      alert('Chyba pri ukladaní: ' + err.message);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Naozaj chcete odstrániť túto udalosť?')) return;

    try {
      const supabase = createBrowserSupabaseClient();
      const { error } = await supabase
        .from('harmonogram')
        .delete()
        .eq('id', id);

      if (error) throw error;
      loadHarmonogram();
    } catch (err: any) {
      console.error('Error deleting harmonogram:', err);
      alert('Chyba pri mazaní: ' + err.message);
    }
  };

  const tileContent = ({ date, view }: { date: Date; view: string }) => {
    if (view === 'month') {
      const dateStr = formatDateForInput(date);
      const events = harmonogram.filter(h => h.datum === dateStr);
      
      if (events.length > 0) {
        return (
          <div className="flex flex-col gap-1 mt-1">
            {events.map((event) => (
              <div
                key={event.id}
                className={`text-xs px-1 rounded ${getWasteTypeColor(event.typ_odpadu)} text-white truncate`}
              >
                {getWasteTypeLabel(event.typ_odpadu)}
              </div>
            ))}
          </div>
        );
      }
    }
    return null;
  };

  const getEventsForDate = (date: Date) => {
    const dateStr = formatDateForInput(date);
    return harmonogram.filter(h => h.datum === dateStr);
  };

  const selectedEvents = getEventsForDate(selectedDate);

  return (
    <DashboardLayout>
      <div>
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold">Harmonogram vývozov</h1>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Calendar */}
          <div className="lg:col-span-2 bg-white rounded-lg shadow p-6">
            <Calendar
              onChange={(value) => {
                if (value instanceof Date) {
                  handleDateClick(value);
                }
              }}
              value={selectedDate}
              tileContent={tileContent}
              className="w-full border-none"
              locale="sk-SK"
            />
          </div>

          {/* Events for Selected Date */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-semibold mb-4">
              {selectedDate.toLocaleDateString('sk-SK', { 
                day: 'numeric',
                month: 'long',
                year: 'numeric'
              })}
            </h2>

            <button
              onClick={() => {
                setFormData({
                  datum: formatDateForInput(selectedDate),
                  typ_odpadu: '',
                  poznamka: '',
                });
                setShowModal(true);
              }}
              className="w-full bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition mb-4"
            >
              + Pridať vývoz
            </button>

            {selectedEvents.length > 0 ? (
              <div className="space-y-3">
                {selectedEvents.map((event) => (
                  <div
                    key={event.id}
                    className="border rounded-lg p-3"
                  >
                    <div className="flex justify-between items-start mb-2">
                      <span className={`px-2 py-1 text-xs rounded ${getWasteTypeColor(event.typ_odpadu)} text-white`}>
                        {getWasteTypeLabel(event.typ_odpadu)}
                      </span>
                      <button
                        onClick={() => handleDelete(event.id)}
                        className="text-red-600 hover:text-red-800 text-sm"
                      >
                        Zmazať
                      </button>
                    </div>
                    {event.poznamka && (
                      <p className="text-sm text-gray-600">{event.poznamka}</p>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500 text-sm text-center py-8">
                Žiadne vývozy naplánované
              </p>
            )}
          </div>
        </div>

        {/* Upcoming Events */}
        <div className="mt-8 bg-white rounded-lg shadow">
          <div className="p-6 border-b">
            <h2 className="text-xl font-semibold">Nadchádzajúce vývozy</h2>
          </div>
          
          {loading ? (
            <p className="text-center py-12">Načítavam...</p>
          ) : (
            <div className="overflow-x-auto">
              {harmonogram.filter(h => new Date(h.datum) >= new Date()).length > 0 ? (
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Dátum</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Typ odpadu</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Poznámka</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Akcie</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {harmonogram
                      .filter(h => new Date(h.datum) >= new Date())
                      .slice(0, 10)
                      .map((event) => (
                        <tr key={event.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {new Date(event.datum).toLocaleDateString('sk-SK', {
                              weekday: 'short',
                              day: 'numeric',
                              month: 'long',
                              year: 'numeric',
                            })}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2 py-1 text-xs rounded ${getWasteTypeColor(event.typ_odpadu)} text-white`}>
                              {getWasteTypeLabel(event.typ_odpadu)}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-500">
                            {event.poznamka || '-'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm">
                            <button
                              onClick={() => handleDelete(event.id)}
                              className="text-red-600 hover:text-red-800"
                            >
                              Zmazať
                            </button>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              ) : (
                <p className="text-center py-12 text-gray-500">Žiadne nadchádzajúce vývozy</p>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-8 max-w-md w-full mx-4">
            <h2 className="text-2xl font-bold mb-6">Pridať vývoz</h2>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Dátum *
                </label>
                <input
                  type="date"
                  required
                  value={formData.datum}
                  onChange={(e) => setFormData({ ...formData, datum: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Typ odpadu *
                </label>
                <select
                  required
                  value={formData.typ_odpadu}
                  onChange={(e) => setFormData({ ...formData, typ_odpadu: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                >
                  <option value="">Vyberte typ</option>
                  <option value="plast">Plast</option>
                  <option value="papier">Papier</option>
                  <option value="sklo">Sklo</option>
                  <option value="zmesovy">Zmesový odpad</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Poznámka
                </label>
                <textarea
                  value={formData.poznamka}
                  onChange={(e) => setFormData({ ...formData, poznamka: e.target.value })}
                  rows={3}
                  className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                  placeholder="napr. Vývoz o 7:00 ráno"
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition"
                >
                  Pridať
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowModal(false);
                    setFormData({ datum: '', typ_odpadu: '', poznamka: '' });
                  }}
                  className="flex-1 bg-gray-200 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-300 transition"
                >
                  Zrušiť
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <style jsx global>{`
        .react-calendar {
          width: 100%;
          border: none;
          font-family: inherit;
        }
        .react-calendar__tile {
          padding: 1em 0.5em;
          height: 80px;
        }
        .react-calendar__tile--active {
          background: #10b981 !important;
          color: white;
        }
        .react-calendar__tile--now {
          background: #dbeafe;
        }
        .react-calendar__month-view__days__day--weekend {
          color: #dc2626;
        }
      `}</style>
    </DashboardLayout>
  );
}
