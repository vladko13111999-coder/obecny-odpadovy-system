import Stripe from 'stripe';
import { VelkostObce, SUBSCRIPTION_PRICES } from '@/types/database';

// Initialize Stripe
export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-12-18.acacia',
});

// Create Stripe checkout session for subscription
export async function createCheckoutSession(
  obecId: number,
  velkostObce: VelkostObce,
  customerEmail: string,
  customerId?: string
) {
  const price = SUBSCRIPTION_PRICES[velkostObce];
  
  // In production, you would create price IDs in Stripe dashboard
  // For now, we'll use the amount directly
  const session = await stripe.checkout.sessions.create({
    customer: customerId,
    customer_email: customerId ? undefined : customerEmail,
    mode: 'subscription',
    payment_method_types: ['card'],
    line_items: [
      {
        price_data: {
          currency: 'eur',
          product_data: {
            name: `Obecný odpadový systém - ${velkostObce.charAt(0).toUpperCase() + velkostObce.slice(1)} obec`,
            description: `Mesačné predplatné pre ${velkostObce} obec`,
          },
          unit_amount: price * 100, // Stripe uses cents
          recurring: {
            interval: 'month',
          },
        },
        quantity: 1,
      },
    ],
    metadata: {
      obec_id: obecId.toString(),
      velkost_obce: velkostObce,
    },
    success_url: `${process.env.NEXT_PUBLIC_APP_URL}/dashboard?payment=success`,
    cancel_url: `${process.env.NEXT_PUBLIC_APP_URL}/dashboard?payment=cancelled`,
  });

  return session;
}

// Create Stripe customer
export async function createStripeCustomer(email: string, name: string) {
  const customer = await stripe.customers.create({
    email,
    name,
    metadata: {
      source: 'odpadovy-system',
    },
  });

  return customer;
}

// Cancel subscription
export async function cancelSubscription(subscriptionId: string) {
  const subscription = await stripe.subscriptions.cancel(subscriptionId);
  return subscription;
}

// Get subscription details
export async function getSubscription(subscriptionId: string) {
  const subscription = await stripe.subscriptions.retrieve(subscriptionId);
  return subscription;
}

// Construct webhook event
export function constructWebhookEvent(
  payload: string | Buffer,
  signature: string
) {
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET!;
  
  try {
    const event = stripe.webhooks.constructEvent(
      payload,
      signature,
      webhookSecret
    );
    return event;
  } catch (err) {
    console.error('Webhook signature verification failed:', err);
    throw err;
  }
}
