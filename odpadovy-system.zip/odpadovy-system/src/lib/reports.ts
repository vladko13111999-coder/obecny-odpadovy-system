import { stringify } from 'csv-stringify/sync';
import { Builder } from 'xml2js';
import ExcelJS from 'exceljs';
import { Vyvoz, Obec } from '@/types/database';
import { getQuarterDateRange } from './utils';

// Generate XML report for ISOH according to vyhláška č. 366/2015 Z.z.
export async function generateXMLReport(
  obec: Obec,
  vyvozy: Vyvoz[],
  kvartal: number,
  rok: number
): Promise<string> {
  const { start, end } = getQuarterDateRange(kvartal, rok);

  // Group waste by type and sum quantities
  const wasteByType = vyvozy.reduce((acc, vyvoz) => {
    const key = vyvoz.kod_odpadu;
    if (!acc[key]) {
      acc[key] = {
        kod_odpadu: vyvoz.kod_odpadu,
        kod_nakladania: vyvoz.kod_nakladania,
        mnozstvo: 0,
      };
    }
    acc[key].mnozstvo += Number(vyvoz.mnozstvo_kg);
    return acc;
  }, {} as Record<string, { kod_odpadu: string; kod_nakladania: string; mnozstvo: number }>);

  // Build XML structure according to ISOH specification
  const xmlData = {
    HlasenieOOdpade: {
      $: {
        xmlns: 'http://www.minzp.sk/isoh',
        verzia: '1.0',
      },
      Identifikacia: {
        TypHlasenia: 'Kvartálne',
        Obdobie: {
          Kvartal: kvartal,
          Rok: rok,
        },
        DatumVytvorenia: new Date().toISOString().split('T')[0],
      },
      Organizacia: {
        ICO: obec.ico || '',
        Nazov: obec.nazov,
        Adresa: {
          Ulica: obec.ulica || '',
          Mesto: obec.mesto || '',
          PSC: obec.psc || '',
        },
      },
      NakladanieSOdpadom: Object.values(wasteByType).map((waste) => ({
        KodOdpadu: waste.kod_odpadu,
        KodNakladania: waste.kod_nakladania,
        MnozstvoKG: waste.mnozstvo.toFixed(2),
      })),
    },
  };

  const builder = new Builder({
    xmldec: { version: '1.0', encoding: 'UTF-8' },
    renderOpts: { pretty: true, indent: '  ' },
  });

  return builder.buildObject(xmlData);
}

// Generate CSV report
export async function generateCSVReport(
  obec: Obec,
  vyvozy: Vyvoz[],
  kvartal: number,
  rok: number
): Promise<string> {
  const { start, end } = getQuarterDateRange(kvartal, rok);

  // Group waste by type
  const wasteByType = vyvozy.reduce((acc, vyvoz) => {
    const key = vyvoz.kod_odpadu;
    if (!acc[key]) {
      acc[key] = {
        kod_odpadu: vyvoz.kod_odpadu,
        typ_odpadu: vyvoz.typ_odpadu,
        kod_nakladania: vyvoz.kod_nakladania,
        mnozstvo: 0,
      };
    }
    acc[key].mnozstvo += Number(vyvoz.mnozstvo_kg);
    return acc;
  }, {} as Record<string, { kod_odpadu: string; typ_odpadu: string; kod_nakladania: string; mnozstvo: number }>);

  const records = [
    ['IČO', 'Názov obce', 'Kód odpadu', 'Typ odpadu', 'Kód nakladania', 'Množstvo (kg)', 'Kvartál', 'Rok'],
    ...Object.values(wasteByType).map((waste) => [
      obec.ico || '',
      obec.nazov,
      waste.kod_odpadu,
      waste.typ_odpadu,
      waste.kod_nakladania,
      waste.mnozstvo.toFixed(2),
      kvartal.toString(),
      rok.toString(),
    ]),
  ];

  return stringify(records, {
    delimiter: ';',
    quoted: true,
  });
}

// Generate XLSX report
export async function generateXLSXReport(
  obec: Obec,
  vyvozy: Vyvoz[],
  kvartal: number,
  rok: number
): Promise<Buffer> {
  const { start, end } = getQuarterDateRange(kvartal, rok);

  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet(`Q${kvartal} ${rok}`);

  // Set column widths
  worksheet.columns = [
    { header: 'IČO', key: 'ico', width: 12 },
    { header: 'Názov obce', key: 'nazov', width: 30 },
    { header: 'Kód odpadu', key: 'kod_odpadu', width: 15 },
    { header: 'Typ odpadu', key: 'typ_odpadu', width: 15 },
    { header: 'Kód nakladania', key: 'kod_nakladania', width: 15 },
    { header: 'Množstvo (kg)', key: 'mnozstvo', width: 15 },
    { header: 'Kvartál', key: 'kvartal', width: 10 },
    { header: 'Rok', key: 'rok', width: 10 },
  ];

  // Style header row
  worksheet.getRow(1).font = { bold: true };
  worksheet.getRow(1).fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FFE0E0E0' },
  };

  // Group waste by type
  const wasteByType = vyvozy.reduce((acc, vyvoz) => {
    const key = vyvoz.kod_odpadu;
    if (!acc[key]) {
      acc[key] = {
        kod_odpadu: vyvoz.kod_odpadu,
        typ_odpadu: vyvoz.typ_odpadu,
        kod_nakladania: vyvoz.kod_nakladania,
        mnozstvo: 0,
      };
    }
    acc[key].mnozstvo += Number(vyvoz.mnozstvo_kg);
    return acc;
  }, {} as Record<string, { kod_odpadu: string; typ_odpadu: string; kod_nakladania: string; mnozstvo: number }>);

  // Add data rows
  Object.values(wasteByType).forEach((waste) => {
    worksheet.addRow({
      ico: obec.ico || '',
      nazov: obec.nazov,
      kod_odpadu: waste.kod_odpadu,
      typ_odpadu: waste.typ_odpadu,
      kod_nakladania: waste.kod_nakladania,
      mnozstvo: waste.mnozstvo.toFixed(2),
      kvartal: kvartal,
      rok: rok,
    });
  });

  // Add summary section
  worksheet.addRow([]);
  worksheet.addRow(['Sumár']);
  const summaryRow = worksheet.lastRow;
  if (summaryRow) {
    summaryRow.font = { bold: true };
  }

  const totalWeight = Object.values(wasteByType).reduce((sum, w) => sum + w.mnozstvo, 0);
  worksheet.addRow(['Celkové množstvo:', `${totalWeight.toFixed(2)} kg`]);

  // Generate buffer
  const buffer = await workbook.xlsx.writeBuffer();
  return Buffer.from(buffer);
}

// Helper to get all collections for a quarter
export function filterCollectionsByQuarter(
  vyvozy: Vyvoz[],
  kvartal: number,
  rok: number
): Vyvoz[] {
  const { start, end } = getQuarterDateRange(kvartal, rok);

  return vyvozy.filter((vyvoz) => {
    const date = new Date(vyvoz.datum);
    return date >= start && date <= end;
  });
}
