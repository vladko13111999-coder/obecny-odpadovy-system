import { createBrowserClient } from '@supabase/ssr';
import { createClient } from '@supabase/supabase-js';

// Browser client for client-side operations
export const createBrowserSupabaseClient = () => {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
};

// Server client for API routes (with service role key)
export const createServerSupabaseClient = () => {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    }
  );
};

// Helper to get current user's obec
export async function getCurrentObec(userId: string) {
  const supabase = createBrowserSupabaseClient();
  
  const { data, error } = await supabase
    .from('obce')
    .select('*')
    .eq('auth_user_id', userId)
    .single();

  if (error) {
    console.error('Error fetching obec:', error);
    return null;
  }

  return data;
}

// Helper to get current user's obyvatel profile (for citizens)
export async function getCurrentObyvatel(userId: string) {
  const supabase = createBrowserSupabaseClient();
  
  const { data, error } = await supabase
    .from('obyvatelia')
    .select('*, obce:obec_id(*)')
    .eq('user_id', userId)
    .single();

  if (error) {
    console.error('Error fetching obyvatel:', error);
    return null;
  }

  return data;
}

// Helper to check if user is starosta (mayor)
export async function isStarosta(userId: string): Promise<boolean> {
  const obec = await getCurrentObec(userId);
  return obec !== null;
}

// Helper to check if user is citizen
export async function isObcan(userId: string): Promise<boolean> {
  const obyvatel = await getCurrentObyvatel(userId);
  return obyvatel !== null;
}

// Helper to check subscription status
export async function checkSubscriptionStatus(obecId: number) {
  const supabase = createBrowserSupabaseClient();
  
  const { data, error } = await supabase
    .from('obce')
    .select('subscription_status, trial_end')
    .eq('id', obecId)
    .single();

  if (error || !data) {
    return { isActive: false, status: 'expired' };
  }

  const now = new Date();
  const trialEnd = new Date(data.trial_end);

  if (data.subscription_status === 'active') {
    return { isActive: true, status: 'active' };
  }

  if (data.subscription_status === 'trial' && now < trialEnd) {
    return { isActive: true, status: 'trial', daysRemaining: Math.ceil((trialEnd.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)) };
  }

  return { isActive: false, status: data.subscription_status };
}
