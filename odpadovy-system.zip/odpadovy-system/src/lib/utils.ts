import { type ClassValue, clsx } from 'clsx';

// Utility for conditional class names (if you want to add clsx later)
export function cn(...inputs: ClassValue[]) {
  return clsx(inputs);
}

// Format date to Slovak locale
export function formatDate(date: string | Date): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleDateString('sk-SK', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

// Format date to short format
export function formatDateShort(date: string | Date): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleDateString('sk-SK');
}

// Format date for input fields (YYYY-MM-DD)
export function formatDateForInput(date: string | Date): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toISOString().split('T')[0];
}

// Get current quarter
export function getCurrentQuarter(): { kvartal: number; rok: number } {
  const now = new Date();
  const month = now.getMonth() + 1;
  const kvartal = Math.ceil(month / 3);
  return { kvartal, rok: now.getFullYear() };
}

// Get quarter date range
export function getQuarterDateRange(kvartal: number, rok: number): { start: Date; end: Date } {
  const startMonth = (kvartal - 1) * 3;
  const start = new Date(rok, startMonth, 1);
  const end = new Date(rok, startMonth + 3, 0);
  return { start, end };
}

// Get quarter name
export function getQuarterName(kvartal: number, rok: number): string {
  return `Q${kvartal} ${rok}`;
}

// Format number with spaces as thousands separator (Slovak format)
export function formatNumber(num: number): string {
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
}

// Format weight (kg)
export function formatWeight(kg: number): string {
  return `${kg.toFixed(2)} kg`;
}

// Format points
export function formatPoints(points: number): string {
  return `${formatNumber(points)} ${points === 1 ? 'bod' : points < 5 ? 'body' : 'bodov'}`;
}

// Get waste type label
export function getWasteTypeLabel(typ: string): string {
  const labels: Record<string, string> = {
    plast: 'Plast',
    papier: 'Papier',
    sklo: 'Sklo',
    zmesovy: 'Zmesový odpad',
  };
  return labels[typ] || typ;
}

// Get waste type color for UI
export function getWasteTypeColor(typ: string): string {
  const colors: Record<string, string> = {
    plast: 'bg-yellow-500',
    papier: 'bg-blue-500',
    sklo: 'bg-green-500',
    zmesovy: 'bg-gray-500',
  };
  return colors[typ] || 'bg-gray-500';
}

// Get subscription status label
export function getSubscriptionStatusLabel(status: string): string {
  const labels: Record<string, string> = {
    trial: 'Skúšobné obdobie',
    active: 'Aktívne',
    expired: 'Vypršané',
    cancelled: 'Zrušené',
  };
  return labels[status] || status;
}

// Get subscription status color
export function getSubscriptionStatusColor(status: string): string {
  const colors: Record<string, string> = {
    trial: 'bg-blue-100 text-blue-800',
    active: 'bg-green-100 text-green-800',
    expired: 'bg-red-100 text-red-800',
    cancelled: 'bg-gray-100 text-gray-800',
  };
  return colors[status] || 'bg-gray-100 text-gray-800';
}

// Calculate days until date
export function daysUntil(date: string | Date): number {
  const d = typeof date === 'string' ? new Date(date) : date;
  const now = new Date();
  const diff = d.getTime() - now.getTime();
  return Math.ceil(diff / (1000 * 60 * 60 * 24));
}

// Check if date is in the past
export function isPast(date: string | Date): boolean {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d < new Date();
}

// Generate verification code for citizens (6 digits)
export function generateVerificationCode(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// Validate Slovak PSC (postal code)
export function validatePSC(psc: string): boolean {
  return /^\d{3}\s?\d{2}$/.test(psc);
}

// Validate Slovak IČO (company ID)
export function validateICO(ico: string): boolean {
  return /^\d{8}$/.test(ico.replace(/\s/g, ''));
}

// Format PSC
export function formatPSC(psc: string): string {
  const cleaned = psc.replace(/\s/g, '');
  if (cleaned.length === 5) {
    return `${cleaned.slice(0, 3)} ${cleaned.slice(3)}`;
  }
  return psc;
}
