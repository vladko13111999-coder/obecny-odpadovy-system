import { ReactNode, useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { createBrowserSupabaseClient } from '@/lib/supabase';
import { Obec } from '@/types/database';
import { getSubscriptionStatusLabel, getSubscriptionStatusColor, daysUntil } from '@/lib/utils';

interface DashboardLayoutProps {
  children: ReactNode;
}

export default function DashboardLayout({ children }: DashboardLayoutProps) {
  const router = useRouter();
  const [obec, setObec] = useState<Obec | null>(null);
  const [loading, setLoading] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  useEffect(() => {
    loadObec();
  }, []);

  const loadObec = async () => {
    try {
      const supabase = createBrowserSupabaseClient();
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push('/auth/login');
        return;
      }

      const { data, error } = await supabase
        .from('obce')
        .select('*')
        .eq('auth_user_id', user.id)
        .single();

      if (error || !data) {
        console.error('Error loading obec:', error);
        router.push('/auth/login');
        return;
      }

      setObec(data);
    } catch (err) {
      console.error('Error:', err);
      router.push('/auth/login');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    const supabase = createBrowserSupabaseClient();
    await supabase.auth.signOut();
    router.push('/');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-lg">Načítavam...</div>
      </div>
    );
  }

  if (!obec) {
    return null;
  }

  const menuItems = [
    { href: '/dashboard', icon: '📊', label: 'Prehľad' },
    { href: '/dashboard/obyvatelia', icon: '👥', label: 'Obyvatelia' },
    { href: '/dashboard/vyvozy', icon: '🗑️', label: 'Vývozy' },
    { href: '/dashboard/odmeny', icon: '🎁', label: 'Odmeny' },
    { href: '/dashboard/harmonogram', icon: '📅', label: 'Harmonogram' },
    { href: '/dashboard/reporty', icon: '📋', label: 'Reporty' },
    { href: '/dashboard/nastavenia', icon: '⚙️', label: 'Nastavenia' },
  ];

  const trialDaysRemaining = obec.subscription_status === 'trial' ? daysUntil(obec.trial_end) : 0;
  const showTrialWarning = obec.subscription_status === 'trial' && trialDaysRemaining <= 7;
  const showExpiredWarning = obec.subscription_status === 'expired' || obec.subscription_status === 'cancelled';

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Trial/Subscription Warning Banner */}
      {showTrialWarning && (
        <div className="bg-yellow-500 text-white px-4 py-3 text-center">
          <p className="font-semibold">
            Skúšobné obdobie končí o {trialDaysRemaining} {trialDaysRemaining === 1 ? 'deň' : trialDaysRemaining < 5 ? 'dni' : 'dní'}
            {' '}- <Link href="/dashboard/nastavenia" className="underline">Aktivujte predplatné</Link>
          </p>
        </div>
      )}
      
      {showExpiredWarning && (
        <div className="bg-red-600 text-white px-4 py-3 text-center">
          <p className="font-semibold">
            Vaše predplatné vypršalo - <Link href="/dashboard/nastavenia" className="underline">Obnoviť predplatné</Link>
          </p>
        </div>
      )}

      <div className="flex">
        {/* Sidebar */}
        <aside className={`${sidebarOpen ? 'w-64' : 'w-20'} bg-white border-r min-h-screen transition-all duration-300`}>
          <div className="p-4">
            <div className="flex items-center justify-between mb-8">
              {sidebarOpen && (
                <h1 className="text-xl font-bold text-green-600">
                  Odpadový systém
                </h1>
              )}
              <button
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="text-gray-500 hover:text-gray-700"
              >
                {sidebarOpen ? '←' : '→'}
              </button>
            </div>

            {sidebarOpen && (
              <div className="mb-6 p-3 bg-green-50 rounded-lg">
                <p className="text-sm font-semibold text-gray-700">{obec.nazov}</p>
                <p className="text-xs text-gray-500">{obec.email}</p>
                <div className="mt-2">
                  <span className={`inline-block px-2 py-1 text-xs rounded ${getSubscriptionStatusColor(obec.subscription_status)}`}>
                    {getSubscriptionStatusLabel(obec.subscription_status)}
                  </span>
                </div>
              </div>
            )}

            <nav className="space-y-1">
              {menuItems.map((item) => {
                const isActive = router.pathname === item.href;
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={`flex items-center px-3 py-2 rounded-lg transition ${
                      isActive
                        ? 'bg-green-100 text-green-700 font-semibold'
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <span className="text-xl mr-3">{item.icon}</span>
                    {sidebarOpen && <span>{item.label}</span>}
                  </Link>
                );
              })}
            </nav>

            <div className="mt-8 pt-8 border-t">
              <button
                onClick={handleLogout}
                className={`flex items-center px-3 py-2 rounded-lg text-red-600 hover:bg-red-50 transition w-full`}
              >
                <span className="text-xl mr-3">🚪</span>
                {sidebarOpen && <span>Odhlásiť sa</span>}
              </button>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8">
          {children}
        </main>
      </div>
    </div>
  );
}
