import { ReactNode, useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { createBrowserSupabaseClient } from '@/lib/supabase';
import { Obyvatel } from '@/types/database';
import { formatPoints } from '@/lib/utils';

interface CitizenLayoutProps {
  children: ReactNode;
}

export default function CitizenLayout({ children }: CitizenLayoutProps) {
  const router = useRouter();
  const [obyvatel, setObyvatel] = useState<Obyvatel | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadObyvatel();
  }, []);

  const loadObyvatel = async () => {
    try {
      const supabase = createBrowserSupabaseClient();
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        router.push('/auth/login');
        return;
      }

      const { data, error } = await supabase
        .from('obyvatelia')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (error || !data) {
        console.error('Error loading obyvatel:', error);
        router.push('/auth/login');
        return;
      }

      setObyvatel(data);
    } catch (err) {
      console.error('Error:', err);
      router.push('/auth/login');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    const supabase = createBrowserSupabaseClient();
    await supabase.auth.signOut();
    router.push('/');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-lg">Načítavam...</div>
      </div>
    );
  }

  if (!obyvatel) {
    return null;
  }

  const menuItems = [
    { href: '/citizen', icon: '🏠', label: 'Prehľad' },
    { href: '/citizen/leaderboard', icon: '🏆', label: 'Rebríček' },
    { href: '/citizen/shop', icon: '🎁', label: 'Obchodík' },
    { href: '/citizen/calendar', icon: '📅', label: 'Kalendár' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
      {/* Header */}
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                Vitajte, {obyvatel.meno}!
              </h1>
              <p className="text-sm text-gray-600">Obecný odpadový systém</p>
            </div>
            <div className="flex items-center gap-6">
              <div className="text-right">
                <p className="text-sm text-gray-600">Vaše body</p>
                <p className="text-2xl font-bold text-green-600">
                  {formatPoints(obyvatel.celkove_body)}
                </p>
              </div>
              <button
                onClick={handleLogout}
                className="text-red-600 hover:text-red-800 text-sm font-medium"
              >
                Odhlásiť sa
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8">
            {menuItems.map((item) => {
              const isActive = router.pathname === item.href;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`flex items-center px-3 py-4 border-b-2 transition ${
                    isActive
                      ? 'border-blue-500 text-blue-600 font-semibold'
                      : 'border-transparent text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <span className="mr-2">{item.icon}</span>
                  <span>{item.label}</span>
                </Link>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {children}
      </main>
    </div>
  );
}
