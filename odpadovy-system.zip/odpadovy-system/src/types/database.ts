// Database types matching the Supabase schema

export type VelkostObce = 'mala' | 'stredna' | 'velka';
export type SubscriptionStatus = 'trial' | 'active' | 'expired' | 'cancelled';
export type TypOdpadu = 'plast' | 'papier' | 'sklo' | 'zmesovy';
export type StavOdmeny = 'aktivna' | 'neaktivna';

export interface Obec {
  id: number;
  auth_user_id: string;
  nazov: string;
  email: string;
  ico?: string;
  ulica?: string;
  mesto?: string;
  psc?: string;
  velkost_obce: VelkostObce;
  subscription_status: SubscriptionStatus;
  trial_start: string;
  trial_end: string;
  stripe_customer_id?: string;
  stripe_subscription_id?: string;
  created_at: string;
}

export interface Obyvatel {
  id: number;
  obec_id: number;
  meno: string;
  priezvisko: string;
  ulica?: string;
  cislo_popisne?: string;
  celkove_body: number;
  user_id?: string;
  created_at: string;
}

export interface Vyvoz {
  id: number;
  obec_id: number;
  obyvatel_id: number;
  datum: string;
  typ_odpadu: TypOdpadu;
  mnozstvo_kg: number;
  kod_odpadu: string;
  kod_nakladania: string;
  created_at: string;
}

export interface Odmena {
  id: number;
  obec_id: number;
  nazov: string;
  popis?: string;
  cena_v_bodoch: number;
  obrazok_url?: string;
  stav: StavOdmeny;
  created_at: string;
  updated_at: string;
}

export interface Harmonogram {
  id: number;
  obec_id: number;
  datum: string;
  typ_odpadu: string;
  poznamka?: string;
  created_at: string;
  updated_at: string;
}

export interface Report {
  id: number;
  obec_id: number;
  kvartal: number;
  rok: number;
  subor_csv?: string;
  subor_xml?: string;
  subor_xlsx?: string;
  vygenerovane_dna: string;
}

// Extended types with relations
export interface VyvozWithObyvatel extends Vyvoz {
  obyvatel?: Obyvatel;
}

export interface ObyvatelWithStats extends Obyvatel {
  pocet_vyvozov?: number;
  posledny_vyvoz?: string;
}

// Form types
export interface ObecRegistrationForm {
  nazov: string;
  email: string;
  password: string;
  ico?: string;
  ulica?: string;
  mesto?: string;
  psc?: string;
  velkost_obce: VelkostObce;
}

export interface ObyvatelForm {
  meno: string;
  priezvisko: string;
  ulica?: string;
  cislo_popisne?: string;
}

export interface VyvozForm {
  obyvatel_id: number;
  datum: string;
  typ_odpadu: TypOdpadu;
  mnozstvo_kg: number;
}

export interface OdmenaForm {
  nazov: string;
  popis?: string;
  cena_v_bodoch: number;
  obrazok_url?: string;
  stav: StavOdmeny;
}

export interface HarmonogramForm {
  datum: string;
  typ_odpadu: string;
  poznamka?: string;
}

// Waste code mapping
export const WASTE_CODES: Record<TypOdpadu, string> = {
  plast: '20 01 39',
  papier: '20 01 01',
  sklo: '20 01 02',
  zmesovy: '20 03 01',
};

// Points calculation
export const POINTS_PER_KG: Record<TypOdpadu, number> = {
  plast: 2,
  papier: 2,
  sklo: 2,
  zmesovy: 0,
};

// Subscription pricing
export const SUBSCRIPTION_PRICES: Record<VelkostObce, number> = {
  mala: 49,
  stredna: 99,
  velka: 149,
};
